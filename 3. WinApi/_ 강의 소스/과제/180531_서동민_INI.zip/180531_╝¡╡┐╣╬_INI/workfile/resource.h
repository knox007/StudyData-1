//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// workfile.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define ID_sound                        1005
#define ID_SOUN                         1005
#define ID_bg                           1006
#define ID_FULL                         1007
#define ID_RESO                         1009
#define sound_STATIC                    1010
#define BG_STATIC                       1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
