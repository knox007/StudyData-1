#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("InfoDlg");
int x;
int y;
TCHAR str[128];

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include "resource.h"

HWND ghScrollSound;
HWND ghScrollBg;
HWND ghComboReso;
HWND ghCheckFull;

int gSound;
int gBg;
int gReso;
int gFull;

char szCurDir[256] = { NULL, };
TCHAR *Items[] = { TEXT("1366 * 768"),TEXT("1360 * 768"),TEXT("1280 * 768") };

BOOL CALLBACK InfoDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_INITDIALOG:

		ghScrollBg = GetDlgItem(hDlg, ID_bg);
		ghScrollSound = GetDlgItem(hDlg, ID_sound);
		ghComboReso = GetDlgItem(hDlg, ID_RESO);
		ghCheckFull = GetDlgItem(hDlg, ID_FULL);

		SetScrollRange(ghScrollBg, SB_CTL, 0, 100, TRUE);
		SetScrollPos(ghScrollBg, SB_CTL, gBg, TRUE);

		SetScrollRange(ghScrollSound, SB_CTL, 0, 100, TRUE);
		SetScrollPos(ghScrollSound, SB_CTL, gSound, TRUE);

		for (int i = 0; i<3; i++)
			SendMessage(ghComboReso, CB_ADDSTRING, 0, (LPARAM)Items[i]);	//	�׸� �߰�.
		SendMessage(ghComboReso, CB_SETCURSEL, gReso, 0);
		/*
		if (SendMessage(chk2StateManual, BM_GETCHECK, 0, 0) == BST_UNCHECKED)
		{
			SendMessage(chk2StateManual, BM_SETCHECK, BST_CHECKED, 0);
			bEllipse = TRUE;
		}
		else
		{
			SendMessage(chk2StateManual, BM_SETCHECK, BST_UNCHECKED, 0);
			bEllipse = FALSE;
		}
		*/

		return TRUE;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case IDOK:			
			return TRUE;


		case IDCANCEL:
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		break;
	}
	return FALSE;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	switch (iMessage) {
	case WM_CREATE:
		GetCurrentDirectory(256, szCurDir);
		strcat_s(szCurDir, "\\jackie.ini");

		gBg = GetPrivateProfileInt("setting", "Bg", 50, szCurDir);
		gSound = GetPrivateProfileInt("setting", "Sound", 50, szCurDir);
		gReso = GetPrivateProfileInt("setting", "Reso", 1, szCurDir);
		gFull = GetPrivateProfileInt("setting", "Full", 1, szCurDir);
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);

		EndPaint(hWnd, &ps);
		return 0;
	case WM_LBUTTONDOWN:
		if (DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG1),
			hWnd, InfoDlgProc) == IDOK)
			InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

