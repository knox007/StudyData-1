#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("0604 Homework");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

struct ThreadParam {
	int x, y, w, h;
	TCHAR* Temp[3];
	int Cnt;
} Param[3] = {
	{ 10, 10, 180, 50, "������", "�̰�ö", "ȭ����", 100},
	{ 210, 10, 180, 50, "ȭ,", "��,", "��", 500 },
	{ 410, 10, 180, 50, "1��", "2��", "3��", 1000 }
};

#define ID_RADIO1 101
#define ID_RADIO2 102
#define ID_RADIO3 103
#define ID_BUTTON1 104
#define ID_BUTTON2 105

DWORD WINAPI ThreadFunc(LPVOID param) {
	HDC hdc;
	ThreadParam* p = (ThreadParam*)param;
	int index = 0;
	hdc = GetDC(hWndMain);
	for (;;) {
		Rectangle(hdc, p->x, p->y, p->x + p->w, p->y + p->h);
		TextOut(hdc, p->x + 5, p->y + 5, p->Temp[index % 3], strlen(p->Temp[index % 3]));
		GdiFlush();
		Sleep(p->Cnt);
		index++;
	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {

	static HANDLE hThread[3];
	static DWORD ThreadID[3];
	static int NowThread = 0;
	int i;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;
		CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			200, 100, 80, 25,
			hWnd,
			(HMENU)ID_BUTTON1,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			200, 130, 80, 25,
			hWnd,
			(HMENU)ID_BUTTON2,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("Thread0"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
			100, 100, 100, 30,
			hWnd,
			(HMENU)ID_RADIO1,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("Thread1"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			100, 120, 100, 30,
			hWnd,
			(HMENU)ID_RADIO2,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("Thread2"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			100, 140, 100, 30,
			hWnd,
			(HMENU)ID_RADIO3,
			g_hInst,
			NULL);

		CheckRadioButton(hWnd, ID_RADIO1, ID_RADIO3, ID_RADIO1);

		for (i = 0; i < 3; i++) {
			hThread[i] = CreateThread(NULL, 0, ThreadFunc, &Param[i], 0, &ThreadID[i]);
		}

		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_RADIO1:
			NowThread = 0;
			break;
		case ID_RADIO2:
			NowThread = 1;
			break;
		case ID_RADIO3:
			NowThread = 2;
			break;
		case ID_BUTTON1:
			SuspendThread(hThread[NowThread]);
			break;
		case ID_BUTTON2:
			ResumeThread(hThread[NowThread]);
			break;
		}
		return 0;

	case WM_DESTROY:
		for (i = 0; i < 3; i++)
			CloseHandle(hThread[i]);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}