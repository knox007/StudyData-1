#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("0601 Homework");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

DWORD WINAPI ThreadFunc(LPVOID temp) {
	HDC hdc;
	BYTE Blue = 0, Red = 0, Green = 0;
	HBRUSH hBrush, hOldBrush;
	RECT* rect = (RECT*)temp;

	hdc = GetDC(hWndMain);
	for (;;) {
		Blue += 5;
		Red += 3;
		Green += 10;
		Sleep(20);
		hBrush = CreateSolidBrush(RGB(Red, Green, Blue));
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		Rectangle(hdc, rect->left, rect->top, rect->right, rect->bottom);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);
	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	DWORD ThreadID_1, ThreadID_2, ThreadID_3, ThreadID_4;
	HANDLE hThread_1, hThread_2, hThread_3, hThread_4;
	static RECT rect1, rect2, rect3, rect4;
	rect1.left = 20;
	rect1.top = 20;
	rect1.right = 200;
	rect1.bottom = 150;

	rect2.left = 250;
	rect2.top = 20;
	rect2.right = 430;
	rect2.bottom = 150;

	rect3.left = 20;
	rect3.top = 200;
	rect3.right = 200;
	rect3.bottom = 330;

	rect4.left = 250;
	rect4.top = 200;
	rect4.right = 430;
	rect4.bottom = 330;

	static int x;
	static int y;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;

		hThread_1 = CreateThread(NULL, 0, ThreadFunc, &rect1, 0, &ThreadID_1);
		CloseHandle(hThread_1);

		hThread_2 = CreateThread(NULL, 0, ThreadFunc, &rect2, 0, &ThreadID_2);
		CloseHandle(hThread_2);

		hThread_3 = CreateThread(NULL, 0, ThreadFunc, &rect3, 0, &ThreadID_3);
		CloseHandle(hThread_3);

		hThread_4 = CreateThread(NULL, 0, ThreadFunc, &rect4, 0, &ThreadID_4);
		CloseHandle(hThread_4);

		return TRUE;

	case WM_LBUTTONDOWN:

		HDC hdc;
		x = LOWORD(lParam);
		y = HIWORD(lParam);

		hdc = GetDC(hWndMain);

		Ellipse(hdc, x-50, y-50, x+50, y+50);

		ReleaseDC(hWndMain, hdc);

		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}