#pragma comment(lib, "msimg32.lib")
#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("API GAME");

void BitDraw1(HDC hdc, int mx, HBITMAP hBit);
void BitDraw2(HDC hdc, int x, int y, HBITMAP hBit);
void BitDraw3(HDC hdc, int x, int y, HBITMAP hBit);
void BitDraw3_1(HDC hdc, int x, int y, HBITMAP hBit);
void BitDraw4(HDC hdc, int x, int y, HBITMAP hBit);
void BitDraw5(HDC hdc, int x, int y, HBITMAP hBit);

struct BULLET {
	int bulletx;
	int bullety;
	bool Life;
};

struct ENEMY {
	int enemyx;
	int enemyy;
	bool Life;
};

struct HP {
	int hpx;
	int hpy;
	bool Life;
};

BULLET bullet[100];
ENEMY enemy[5];
HP hp;

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {

	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include "resource.h"
#include <time.h>
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {

	srand(time(0));

	HDC hdc;
	static int mx = 0, x = 0, y = 0, cnt = 0, bulletcount;;
	static HBITMAP hbit1, hbit2, hbit3, hbit4, hbit5;

	switch (iMessage) {
	case WM_CREATE:
		SetTimer(hWnd, 1, 50, NULL);
		hbit1 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		hbit2 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP2));
		hbit3 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP3));
		hbit4 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP4));
		hbit5 = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP5));
		return 0;

	case WM_TIMER:
		mx -= 10;
		if (mx <= -1600) {
			mx = 0;
		}

		for (int i = 0; i<100; i++) {
			if (bullet[i].Life == true) {
				bullet[i].bulletx += 50;
			}
			if (bullet[i].bulletx > 1500) {
				bullet[i].Life = false;
			}
		}

		for (int i = 0; i<5; i++) {
			if (enemy[i].Life == false) {
				enemy[i].Life = true;
				enemy[i].enemyx = rand() % 500 + 600;
				enemy[i].enemyy = rand() % 100 + 300;
			}
		}

		if (hp.Life == false && cnt >= 5) {
			hp.Life = true;
			hp.hpx = rand() % 200 + 300;
			hp.hpy = rand() % 300 + 300;
		}

		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 5; j++) {
				if (bullet[i].Life == true) {
					if (bullet[i].bulletx >= enemy[j].enemyx && bullet[i].bullety >= enemy[j].enemyy - 45 && bullet[i].bullety <= enemy[j].enemyy + 55) {
						bullet[i].Life = false;
						enemy[j].Life = false;
						cnt++;
					}
				}
			}
		}

		if (hp.hpx <= x + 180 && hp.hpx >= x && hp.hpy <= y + 800 && hp.hpy >= y + 600) {
			hp.Life = false;
			cnt = 0;
		}

		InvalidateRect(hWnd, NULL, FALSE);
		return 0;

	case WM_GETMINMAXINFO:		// ������â ����
		((MINMAXINFO *)lParam)->ptMaxTrackSize.x = 1600;
		((MINMAXINFO *)lParam)->ptMaxTrackSize.y = 800;
		((MINMAXINFO *)lParam)->ptMinTrackSize.x = 1600;
		((MINMAXINFO *)lParam)->ptMinTrackSize.y = 800;
		return 0;

	case WM_KEYDOWN:
		switch (wParam) {
		case VK_LEFT:
			if (x >= 0) {
				x -= 8;
			}
			break;
		case VK_RIGHT:
			if (x <= 1500) {
				x += 8;
			}
			break;
		case VK_UP:
			if (y >= -300) {
				y -= 8;
			}
			break;
		case VK_DOWN:
			if (y <= 0) {
				y += 8;
			}
			break;
		case VK_SPACE:
			bullet[bulletcount].bulletx = x + 150;
			bullet[bulletcount].bullety = y + 600;
			bullet[bulletcount].Life = true;
			bulletcount++;
			if (bulletcount >= 100) {
				bulletcount = 0;
			}
		}

		InvalidateRect(hWnd, NULL, FALSE);
		return 0;
		
	case WM_PAINT:

		PAINTSTRUCT ps;
		HDC MemDC;
		static HBITMAP MyBitMap;
		HBITMAP OldBitMap;

		hdc = BeginPaint(hWnd, &ps);

		if (MyBitMap) {
			DeleteObject(MyBitMap);
		}

		MemDC = CreateCompatibleDC(hdc);
		MyBitMap = CreateCompatibleBitmap(hdc, 3200, 800);
		OldBitMap = (HBITMAP)SelectObject(MemDC, MyBitMap);
		PatBlt(MemDC, 0, 0, 3200, 800, WHITENESS);

		BitDraw1(MemDC, mx, hbit1);
		BitDraw2(MemDC, x, y, hbit2);
		BitDraw3(MemDC, x, y, hbit3);

		for (int i = 0; i<100; i++) {
			if (bullet[i].Life == true) {
				BitDraw3_1(MemDC, bullet[i].bulletx, bullet[i].bullety, hbit3);
			}
		}

		for (int i = 0; i<5; i++) {
			if (enemy[i].Life == true) {
				BitDraw4(MemDC, enemy[i].enemyx, enemy[i].enemyy, hbit4);
			} else {
				BitDraw5(MemDC, enemy[i].enemyx, enemy[i].enemyy, hbit5);
			}
		}

		BitBlt(hdc, 0, 0, 1600, 800, MemDC, 0, 0, SRCCOPY);

		SelectObject(MemDC, OldBitMap);
		ReleaseDC(hWnd, hdc);
		DeleteDC(MemDC); 

		EndPaint(hWnd, &ps);
		return 0;

	case WM_DESTROY:
		DeleteObject(hbit1);
		DeleteObject(hbit2);
		DeleteObject(hbit3);
		DeleteObject(hbit4);
		DeleteObject(hbit5);
		PostQuitMessage(0);
		return 0;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

void BitDraw1(HDC hdc, int mx, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);
	
	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	StretchBlt(hdc, mx, 0, 1600, 800, MemDC, 0, 0, bx, by, SRCCOPY);
	StretchBlt(hdc, 1600 + mx, 0, 1600, 800, MemDC, 0, 0, bx, by, SRCCOPY);

	SelectObject(MemDC, OldBitMap);
}

void BitDraw2(HDC hdc, int x, int y, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	TransparentBlt(hdc, 50 + x, 530 + y, bx / 2, by / 2, MemDC, 0, 0, bx, by, RGB(255, 0, 0));		// ���, ����x, ����y, x����, y����, ��𲨸�, ����x, ����y, x����, y����, ���� ����

	SelectObject(MemDC, OldBitMap);
}

void BitDraw3(HDC hdc, int x, int y, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	TransparentBlt(hdc, 20 + x, 600 + y, bx / 5, by / 5, MemDC, 0, 0, bx, by, RGB(255, 0, 0));

	SelectObject(MemDC, OldBitMap);
}

void BitDraw3_1(HDC hdc, int x, int y, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	TransparentBlt(hdc, x, y, 100, 100, MemDC, 0, 0, bx, by, RGB(255, 0, 0));

	SelectObject(MemDC, OldBitMap);
}

void BitDraw4(HDC hdc, int x, int y, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	TransparentBlt(hdc, x, y, bx / 7, by / 7, MemDC, 0, 0, bx, by, RGB(255, 0, 0));

	SelectObject(MemDC, OldBitMap);
}

void BitDraw5(HDC hdc, int x, int y, HBITMAP hBit) {

	HBITMAP OldBitMap;
	HDC MemDC;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);

	GetObject(hBit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	OldBitMap = (HBITMAP)SelectObject(MemDC, hBit);

	TransparentBlt(hdc, x, y, bx / 10, by / 10, MemDC, 0, 0, bx, by, RGB(255, 0, 0));

	SelectObject(MemDC, OldBitMap);
}



