//====================================================
#pragma once
#include "CObject.h"
class CView;
//===================================================

typedef struct tagMessageMap
{
	UINT iMsg;
	CViewFunPointer fp;

}MessageMap;

class CView : public CObject
{
public:
	static MessageMap messageMap[];

public:
	void OnCreate();
	void OnDraw();
	void OnLButtonDown();
	void OnDestroy();
};
//====================================================
extern CView g_View;
//====================================================