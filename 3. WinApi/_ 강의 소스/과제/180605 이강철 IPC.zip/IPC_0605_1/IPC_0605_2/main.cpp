#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("chating2");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		100, 100, 1000, 500,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#define DLIST 2000
#define DNAME 2001
#define DTEXT 2002
#define DBTN  2003

HWND hList, hName, hText, hBtn, hWnd1;
TCHAR message[256], name[128], text[128];

DWORD WINAPI ThreadFunc(LPVOID temp)
{
	for (;;) {
		hWnd1 = FindWindow(NULL, "chating1");
		if (hWnd1 == NULL) {
			wsprintf(message, "%s", "������ �������ϴ�.");
			SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)message);
			break;
		}
	}
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	COPYDATASTRUCT cds, *pcds;
	HDC hdc;
	static HANDLE hThread;
	DWORD ThreadID;

	switch (iMessage) {
	case WM_CREATE:
		hThread = CreateThread(NULL, 0, ThreadFunc, NULL, 0, &ThreadID);
		SuspendThread(hThread);

		hList = CreateWindow(TEXT("listbox"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY,
			10, 10, 960, 400,
			hWnd,
			(HMENU)DLIST,
			g_hInst,
			NULL);
		CreateWindow(TEXT("static"),
			TEXT("�̸�"),
			WS_CHILD | WS_VISIBLE | BS_CENTER,
			10, 410, 35, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);
		hName = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER,
			50, 410, 100, 25,
			hWnd,
			(HMENU)DNAME,
			g_hInst,
			NULL);
		CreateWindow(TEXT("static"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_CENTER,
			170, 410, 35, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);
		hText = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER,
			210, 410, 640, 25,
			hWnd,
			(HMENU)DNAME,
			g_hInst,
			NULL);
		hBtn = CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
			870, 410, 100, 25,
			hWnd,
			(HMENU)DBTN,
			g_hInst,
			NULL);
		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case DBTN:
			GetWindowText(hName, name, 128);
			GetWindowText(hText, text, 128);
			wsprintf(message, "%s : %s", name, text);
			
			SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)message);
			SetWindowText(hText, "");
			cds.dwData = 0;
			cds.cbData = lstrlen(message)+1;
			cds.lpData = message;
			hWnd1 = FindWindow(NULL, "chating1");
			if (hWnd1 != NULL) {
				SendMessage(hWnd1, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&cds);
				ResumeThread(hThread);
			}
			break;
		}
		return 0;
	case WM_COPYDATA:
		pcds = (PCOPYDATASTRUCT)lParam;
		hdc = GetDC(hWnd);
		
		SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)pcds->lpData);
		ReleaseDC(hWnd, hdc);
		return 0;
	case WM_DESTROY:
		CloseHandle(hThread);

		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

