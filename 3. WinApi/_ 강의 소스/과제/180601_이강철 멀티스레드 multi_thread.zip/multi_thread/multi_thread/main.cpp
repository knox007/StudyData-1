#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("Thread");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

DWORD WINAPI ThreadFunc(LPVOID temp)
{
	HDC hdc;
	BYTE Blue = 0;
	HBRUSH hBrush, hOldBrush;
	RECT* rect = (RECT*)temp;
	hdc = GetDC(hWndMain);
	for (;;) {
		Blue += 5;
		Sleep(20);
		hBrush = CreateSolidBrush(RGB(0, 0, Blue));
		hOldBrush = (HBRUSH)SelectObject(hdc, hBrush);
		Rectangle(hdc, rect->left, rect->top, rect->right, rect->bottom);
		SelectObject(hdc, hOldBrush);
		DeleteObject(hBrush);
	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	static int x, y;
	DWORD ThreadID, ThreadID2, ThreadID3, ThreadID4;
	HANDLE hThread, hThread2, hThread3, hThread4;
	static RECT rect, rect2, rect3, rect4;
	rect.left = 10;
	rect.top = 10;
	rect.right = 100;
	rect.bottom = 100;
	
	rect2.left = 160;
	rect2.top = 160;
	rect2.right = 250;
	rect2.bottom = 250;

	rect3.left = 10;
	rect3.top = 160;
	rect3.right = 100;
	rect3.bottom = 250;

	rect4.left = 160;
	rect4.top = 10;
	rect4.right = 250;
	rect4.bottom = 100;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;
		hThread = CreateThread(NULL, 0, ThreadFunc, &rect, 0, &ThreadID);
		hThread2 = CreateThread(NULL, 0, ThreadFunc, &rect2, 0, &ThreadID2);
		hThread3 = CreateThread(NULL, 0, ThreadFunc, &rect3, 0, &ThreadID3);
		hThread4 = CreateThread(NULL, 0, ThreadFunc, &rect4, 0, &ThreadID4);

		CloseHandle(hThread);					
		CloseHandle(hThread2);
		CloseHandle(hThread3);
		CloseHandle(hThread4);

		return TRUE;
	case WM_LBUTTONDOWN:
		hdc = GetDC(hWnd);
		x = LOWORD(lParam);
		y = HIWORD(lParam);
		Ellipse(hdc, x-10, y-10, x+10, y+10);
		ReleaseDC(hWnd, hdc);
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
