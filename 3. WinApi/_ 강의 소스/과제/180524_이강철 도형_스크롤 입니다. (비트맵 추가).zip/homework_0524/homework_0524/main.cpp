#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("Homework");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

HWND hList, hCombo, hRed, hGreen, hBlue, hEdit_red, hEdit_green, hEdit_blue, hView_x, hView_y, hEdit_x, hEdit_y;
int TempPos;
int brush_red, brush_green, brush_blue, pen_red, pen_green, pen_blue, view_x, view_y;
int list_index, combo_index;
TCHAR CTemp[128];

#define LIST_BOX 201
#define ID_COMBOBOX 202
#define SCROLLBAR_RED 203
#define SCROLLBAR_GREEN 204
#define SCROLLBAR_BLUE 205
#define SCROLLBAR_X 206
#define SCROLLBAR_Y 207

#include "resource.h"
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	static HBITMAP my_bitmap_img;

	switch (iMessage) {
	case WM_CREATE:
		my_bitmap_img = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));

		CreateWindow(TEXT("static"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE,
			10, 10, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		hList = CreateWindow(TEXT("listbox"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY,	
			10, 30, 60, 80,
			hWnd,
			(HMENU)LIST_BOX,
			g_hInst,
			NULL);

			SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)TEXT("����"));
			SendMessage(hList, LB_ADDSTRING, 1, (LPARAM)TEXT("�ڽ�"));
			SendMessage(hList, LB_ADDSTRING, 2, (LPARAM)TEXT("��"));
			SendMessage(hList, LB_ADDSTRING, 3, (LPARAM)TEXT("��Ʈ��"));
			SendMessage(hList, LB_SETCURSEL, 0, NULL);
			

			CreateWindow(TEXT("static"),
				TEXT("����"),
				WS_CHILD | WS_VISIBLE,
				100, 10, 100, 25,
				hWnd,
				(HMENU)-1,	
				g_hInst,
				NULL);

			hCombo = CreateWindow(TEXT("combobox"),
				NULL,
				WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
				100, 30, 100, 60,
				hWnd,
				(HMENU)ID_COMBOBOX,
				g_hInst,
				NULL);

			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("��"));
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)TEXT("�귯��"));
			SendMessage(hCombo, CB_SETCURSEL, 0, 0);

			CreateWindow(TEXT("static"),
				TEXT("R"),
				WS_CHILD | WS_VISIBLE,
				230, 10, 20, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);

			hRed = CreateWindow(TEXT("scrollbar"),
				NULL,
				WS_CHILD | WS_VISIBLE | SBS_HORZ,	
				250, 10, 400, 20,
				hWnd,
				(HMENU)SCROLLBAR_RED,
				g_hInst,
				NULL);
			SetScrollRange(hRed, SB_CTL, 0, 255, TRUE);
			SetScrollPos(hRed, SB_CTL, 0, TRUE);

			hEdit_red = CreateWindow(TEXT("edit"),
				NULL,			
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,	
				660, 10, 60, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);
			SetWindowText(hEdit_red, "0");

			CreateWindow(TEXT("static"),
				TEXT("G"),
				WS_CHILD | WS_VISIBLE,
				230, 40, 20, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);

			hGreen = CreateWindow(TEXT("scrollbar"),
				NULL,
				WS_CHILD | WS_VISIBLE | SBS_HORZ,
				250, 40, 400, 20,
				hWnd,
				(HMENU)SCROLLBAR_GREEN,
				g_hInst,
				NULL);
			SetScrollRange(hGreen, SB_CTL, 0, 255, TRUE);
			SetScrollPos(hGreen, SB_CTL, 0, TRUE);

			hEdit_green = CreateWindow(TEXT("edit"),
				NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,
				660, 40, 60, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);
			SetWindowText(hEdit_green, "0");

			CreateWindow(TEXT("static"),
				TEXT("B"),
				WS_CHILD | WS_VISIBLE,
				230, 70, 20, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);

			hBlue = CreateWindow(TEXT("scrollbar"),
				NULL,
				WS_CHILD | WS_VISIBLE | SBS_HORZ,
				250, 70, 400, 20,
				hWnd,
				(HMENU)SCROLLBAR_BLUE,
				g_hInst,
				NULL);
			SetScrollRange(hBlue, SB_CTL, 0, 255, TRUE);
			SetScrollPos(hBlue, SB_CTL, 0, TRUE);

			hEdit_blue = CreateWindow(TEXT("edit"),
				NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,
				660, 70, 60, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);
			SetWindowText(hEdit_blue, "0");

			hView_x = CreateWindow(TEXT("scrollbar"),
				NULL,
				WS_CHILD | WS_VISIBLE | SBS_HORZ,
				30, 330, 300, 20,
				hWnd,
				(HMENU)SCROLLBAR_X,
				g_hInst,
				NULL);
			SetScrollRange(hView_x, SB_CTL, 0, 100, TRUE);
			SetScrollPos(hView_x, SB_CTL, 0, TRUE);

			hEdit_x = CreateWindow(TEXT("edit"),
				NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,
				160, 360, 60, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);
			SetWindowText(hEdit_x, "0");

			hView_y = CreateWindow(TEXT("scrollbar"),
				NULL,
				WS_CHILD | WS_VISIBLE | SBS_VERT,
				350, 120, 20, 200,
				hWnd,
				(HMENU)SCROLLBAR_Y,
				g_hInst,
				NULL);
			SetScrollRange(hView_y, SB_CTL, 0, 100, TRUE);
			SetScrollPos(hView_y, SB_CTL, 0, TRUE);

			hEdit_y = CreateWindow(TEXT("edit"),
				NULL,
				WS_CHILD | WS_VISIBLE | WS_BORDER | ES_CENTER | ES_READONLY,
				380, 220, 60, 20,
				hWnd,
				(HMENU)-1,
				g_hInst,
				NULL);
			SetWindowText(hEdit_y, "0");
			
		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case LIST_BOX:
			switch (HIWORD(wParam)) {
			case LBN_SELCHANGE:	
			list_index = SendMessage(hList, LB_GETCURSEL, 0, 0);			
			}
		case ID_COMBOBOX:
			switch (HIWORD(wParam)) {
			case CBN_SELCHANGE:
			combo_index = SendMessage(hCombo, CB_GETCURSEL, 0, 0);
			if (combo_index == 0) {
				SetScrollPos(hRed, SB_CTL, pen_red, TRUE);
				SetScrollPos(hGreen, SB_CTL, pen_green, TRUE);
				SetScrollPos(hBlue, SB_CTL, pen_blue, TRUE);
				wsprintf(CTemp, TEXT("%d"), pen_red);
				SetWindowText(hEdit_red, CTemp);
				wsprintf(CTemp, TEXT("%d"), pen_green);
				SetWindowText(hEdit_green, CTemp);
				wsprintf(CTemp, TEXT("%d"), pen_blue);
				SetWindowText(hEdit_blue, CTemp);
			} else {
				SetScrollPos(hRed, SB_CTL, brush_red, TRUE);
				SetScrollPos(hGreen, SB_CTL, brush_green, TRUE);
				SetScrollPos(hBlue, SB_CTL, brush_blue, TRUE);
				wsprintf(CTemp, TEXT("%d"), brush_red);
				SetWindowText(hEdit_red, CTemp);
				wsprintf(CTemp, TEXT("%d"), brush_green);
				SetWindowText(hEdit_green, CTemp);
				wsprintf(CTemp, TEXT("%d"), brush_blue);
				SetWindowText(hEdit_blue, CTemp);
			}
			}
		}
		
		InvalidateRect(hWnd, NULL, FALSE);
		return 0;
	case WM_HSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINELEFT:
			TempPos = max(0, TempPos - 1);
			break;
		case SB_LINERIGHT:
			TempPos = min(255, TempPos + 1);
			break;
		case SB_PAGELEFT:
			TempPos = max(0, TempPos - 10);
			break;
		case SB_PAGERIGHT:
			TempPos = min(255, TempPos + 10);
			break;
		case SB_THUMBTRACK:
			TempPos = HIWORD(wParam);
			break;
		}
		
		if ((HWND)lParam == hRed && combo_index == 0) {
			pen_red = TempPos;
			wsprintf(CTemp, TEXT("%d"), pen_red);
			SetWindowText(hEdit_red, CTemp);
		} else if ((HWND)lParam == hGreen && combo_index == 0) {
			pen_green = TempPos;
			wsprintf(CTemp, TEXT("%d"), pen_green);
			SetWindowText(hEdit_green, CTemp);
		} else if ((HWND)lParam == hBlue && combo_index == 0) {
			pen_blue = TempPos;
			wsprintf(CTemp, TEXT("%d"), pen_blue);
			SetWindowText(hEdit_blue, CTemp);
		} else if ((HWND)lParam == hRed && combo_index == 1) {
			brush_red = TempPos;
			wsprintf(CTemp, TEXT("%d"), brush_red);
			SetWindowText(hEdit_red, CTemp);
		} else if ((HWND)lParam == hGreen && combo_index == 1) {
			brush_green = TempPos;
			wsprintf(CTemp, TEXT("%d"), brush_green);
			SetWindowText(hEdit_green, CTemp);
		} else if ((HWND)lParam == hBlue && combo_index == 1) {
			brush_blue = TempPos;
			wsprintf(CTemp, TEXT("%d"), brush_blue);
			SetWindowText(hEdit_blue, CTemp);
		} else if ((HWND)lParam == hView_x) {
			view_x = TempPos;
			wsprintf(CTemp, TEXT("%d"), view_x);
			SetWindowText(hEdit_x, CTemp);
		} 

		SetScrollPos((HWND)lParam, SB_CTL, TempPos, TRUE);
		InvalidateRect(hWnd, NULL, FALSE);
		return 0;
	case WM_VSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINEUP:
			TempPos = max(0, TempPos - 1);
			break;
		case SB_LINEDOWN:
			TempPos = min(255, TempPos + 1);
			break;
		case SB_PAGEUP:
			TempPos = max(0, TempPos - 10);
			break;
		case SB_PAGEDOWN:
			TempPos = min(255, TempPos + 10);
			break;
		case SB_THUMBTRACK:
			TempPos = HIWORD(wParam);
			break;
		}
		
		view_y = TempPos;
		wsprintf(CTemp, TEXT("%d"), view_y);
		SetWindowText(hEdit_y, CTemp);
		
		SetScrollPos((HWND)lParam, SB_CTL, TempPos, TRUE);
		InvalidateRect(hWnd, NULL, FALSE);
		return 0;
	case WM_PAINT:
		HDC hdc, MemDC;
		HBITMAP MyBitmap, OldBitmap;
		PAINTSTRUCT ps;
		HBRUSH Brush, oBrush;
		HPEN Pen, oPen;

		hdc = BeginPaint(hWnd, &ps);
		MemDC = CreateCompatibleDC(hdc);
		MyBitmap = CreateCompatibleBitmap(hdc, 800, 800);
		OldBitmap = (HBITMAP)SelectObject(MemDC, MyBitmap);
		PatBlt(MemDC, 0, 0, 800, 800, WHITENESS);
		
		Pen = CreatePen(PS_SOLID, 2, RGB(pen_red, pen_green, pen_blue));
		oPen = (HPEN)SelectObject(MemDC, Pen);
		Brush = CreateSolidBrush(RGB(brush_red, brush_green, brush_blue));
		oBrush = (HBRUSH)SelectObject(MemDC, Brush);
		
		if (list_index == 0) {
			MoveToEx(MemDC, 20, 20, NULL);
			LineTo(MemDC, 280, 280);
		} else if (list_index == 1) {
			Rectangle(MemDC, 20, 20, 280, 280);
		} else if (list_index == 2) {
			Ellipse(MemDC, 20, 20, 280, 280);
		} else if (list_index == 3) {
			(HBITMAP)SelectObject(MemDC, my_bitmap_img);
		}

		BitBlt(hdc, 30, 110, 310, 210, MemDC, 0 + (view_x * 2), 0 + (view_y * 2), SRCCOPY);
	
		SelectObject(MemDC, oPen);
		SelectObject(MemDC, oBrush);
		DeleteObject(Pen);
		DeleteObject(Brush);
		DeleteObject(MyBitmap);
		DeleteDC(MemDC);
		DeleteDC(hdc);
		EndPaint(hWnd, &ps);

		/*
		HDC hdc;
		PAINTSTRUCT ps;
		HBRUSH Brush, oBrush;
		HPEN Pen, oPen;

		hdc = BeginPaint(hWnd, &ps);

		Pen = CreatePen(PS_SOLID, 2, RGB(pen_red, pen_green, pen_blue));
		oPen = (HPEN)SelectObject(hdc, Pen);
		Brush = CreateSolidBrush(RGB(brush_red, brush_green, brush_blue));
		oBrush = (HBRUSH)SelectObject(hdc, Brush);

		if (list_index == 0) {
			MoveToEx(hdc, 70, 170, NULL);
			LineTo(hdc, 300, 300);
		}
		else if (list_index == 1) {
			Rectangle(hdc, 50, 150, 300, 300);
		}
		else if (list_index == 2) {
			Ellipse(hdc, 50, 150, 300, 300);
		}

		SelectObject(hdc, oPen);
		SelectObject(hdc, oBrush);
		DeleteObject(Pen);
		DeleteObject(Brush);
		EndPaint(hWnd, &ps);
		*/
		return 0;
	case WM_DESTROY:
		DeleteObject(my_bitmap_img);

		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
