#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("Thread");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

HWND hEdit, hEdit2, hEdit3;

struct thred_st {
	TCHAR text[32];
	TCHAR text2[32];
	TCHAR text3[32];
	int x;
	int y;
	int sleep_time;
};

DWORD WINAPI ThreadFunc(LPVOID temp)
{
	HDC hdc;
	thred_st* CTemp = (thred_st*)temp;
	hdc = GetDC(hWndMain);
	TCHAR TNull[128] = "                  ";
	for (;;) {
		
		TextOut(hdc, CTemp->x, CTemp->y, CTemp->text, lstrlen(CTemp->text));
		TextOut(hdc, CTemp->x, CTemp->y, TNull, lstrlen(TNull));
		Sleep(CTemp->sleep_time);
		
		TextOut(hdc, CTemp->x, CTemp->y, CTemp->text2, lstrlen(CTemp->text2));
		TextOut(hdc, CTemp->x, CTemp->y, TNull, lstrlen(TNull));
		Sleep(CTemp->sleep_time);
		
		TextOut(hdc, CTemp->x, CTemp->y, CTemp->text3, lstrlen(CTemp->text3));
		TextOut(hdc, CTemp->x, CTemp->y, TNull, lstrlen(TNull));
		Sleep(CTemp->sleep_time);
	}
	
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	static DWORD ThreadID, ThreadID2, ThreadID3;
	static HANDLE hThread, hThread2, hThread3;
	HWND hRbttn, hRbttn2, hRbttn3;
	HWND hBtn, hBtn2;
	TCHAR Temp[128];
	static int radio_index = 0;
	static int thread_cnt = 0, thread_cnt2 = 0, thread_cnt3 = 0;

	static thred_st thread_temp[3];
	wsprintf(thread_temp[0].text, "%s", "������");
	wsprintf(thread_temp[0].text2, "%s", "�׽�Ʈ��");
	wsprintf(thread_temp[0].text3, "%s", "ȣ��ȣ��");
	thread_temp[0].x = 15;
	thread_temp[0].y = 15;
	thread_temp[0].sleep_time = 500;

	wsprintf(thread_temp[1].text, "%s", "SK");
	wsprintf(thread_temp[1].text2, "%s", "���̹���");
	wsprintf(thread_temp[1].text3, "%s", "������");
	thread_temp[1].x = 265;
	thread_temp[1].y = 15;
	thread_temp[1].sleep_time = 600;

	wsprintf(thread_temp[2].text, "%s", "�λ�");
	wsprintf(thread_temp[2].text2, "%s", "����");
	wsprintf(thread_temp[2].text3, "%s", "���°ų�");
	thread_temp[2].x = 515;
	thread_temp[2].y = 15;
	thread_temp[2].sleep_time = 700;

	#define ID_EDIT 200
	#define ID_EDIT2 201
	#define ID_EDIT3 202
	#define ID_RADIO 203
	#define ID_RADIO2 204
	#define ID_RADIO3 205
	#define ID_BTN 206
	#define ID_BTN2 207

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;
		hThread = CreateThread(NULL, 0, ThreadFunc, &thread_temp[0], 0, &ThreadID);
		hThread2 = CreateThread(NULL, 0, ThreadFunc, &thread_temp[1], 0, &ThreadID2);
		hThread3 = CreateThread(NULL, 0, ThreadFunc, &thread_temp[2], 0, &ThreadID3);
		
		hRbttn = CreateWindow(TEXT("button"),
			TEXT("Thread0"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,	
			100, 100, 100, 30,
			hWnd,
			(HMENU)ID_RADIO,
			g_hInst,
			NULL);

		hRbttn2 = CreateWindow(TEXT("button"),
			TEXT("Thread1"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			100, 130, 100, 30,
			hWnd,
			(HMENU)ID_RADIO2,
			g_hInst,
			NULL);

		hRbttn3 = CreateWindow(TEXT("button"),
			TEXT("Thread2"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			100, 160, 100, 30,
			hWnd,
			(HMENU)ID_RADIO3,
			g_hInst,
			NULL);

		CheckRadioButton(hWnd, ID_RADIO, ID_RADIO3, ID_RADIO);

		hEdit = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			210, 100, 30, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);
		SetWindowText(hEdit, "0");

		hEdit2 = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			210, 130, 30, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);
		SetWindowText(hEdit2, "0");

		hEdit3 = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			210, 160, 30, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);
		SetWindowText(hEdit3, "0");

		hBtn = CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
			250, 120, 100, 25,
			hWnd,
			(HMENU)ID_BTN,
			g_hInst,
			NULL);

		hBtn2 = CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
			250, 150, 100, 25,
			hWnd,
			(HMENU)ID_BTN2,
			g_hInst,
			NULL);

		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_RADIO:
			radio_index = 0;
			break;
		case ID_RADIO2:
			radio_index = 1;
			break;
		case ID_RADIO3:
			radio_index = 2;
			break;
		case ID_BTN:
			if (radio_index == 0) {
				thread_cnt++;
				wsprintf(Temp, "%d", thread_cnt);
				SetWindowText(hEdit, Temp);
				SuspendThread(hThread);
			} else if (radio_index == 1) {
				thread_cnt2++;
				wsprintf(Temp, "%d", thread_cnt2);
				SetWindowText(hEdit2, Temp);
				SuspendThread(hThread2);
			} else if (radio_index == 2) {
				thread_cnt3++;
				wsprintf(Temp, "%d", thread_cnt3);
				SetWindowText(hEdit3, Temp);
				SuspendThread(hThread3);
			}
			break;
		case ID_BTN2:
			if (radio_index == 0) {
				thread_cnt--;
				if (thread_cnt < 0)
					thread_cnt = 0;

				wsprintf(Temp, "%d", thread_cnt);
				SetWindowText(hEdit, Temp);
				ResumeThread(hThread);
			} else if (radio_index == 1) {
				thread_cnt2--;
				if (thread_cnt2 < 0)
					thread_cnt2 = 0;

				wsprintf(Temp, "%d", thread_cnt2);
				SetWindowText(hEdit2, Temp);				
				ResumeThread(hThread2);
			} else if (radio_index == 2) {
				thread_cnt3--;
				if (thread_cnt3 < 0)
					thread_cnt3 = 0;

				wsprintf(Temp, "%d", thread_cnt3);
				SetWindowText(hEdit3, Temp);				
				ResumeThread(hThread3);
			}
			break;
		}

		//InvalidateRect(hWnd, NULL, TRUE);
		return 0;
	case WM_PAINT:
		HDC hdc;
		PAINTSTRUCT ps;
		hdc = BeginPaint(hWnd, &ps);

		Rectangle(hdc, 10, 10, 200, 50);
		Rectangle(hdc, 260, 10, 450, 50);
		Rectangle(hdc, 510, 10, 700, 50);

		DeleteDC(hdc);
		EndPaint(hWnd, &ps);

		return 0;
	case WM_DESTROY:
		CloseHandle(hThread);
		CloseHandle(hThread2);
		CloseHandle(hThread3);

		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
