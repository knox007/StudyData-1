#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("CHAT_CLIENT");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		100, 100, 500, 300,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#define ID_NAME 100
#define ID_LIST 101
#define ID_ENTER 102
#define ID_STORY 103

HWND hName, hList, hEnter, hStory;
TCHAR str_name[128], str_list[128], str_story[2048];
TCHAR str[128] = "���� ������.";
HWND hWnd2;
HANDLE hThread;

DWORD WINAPI ThreadFunc(LPVOID temp) {

	HDC hdc;
	hdc = GetDC(hWndMain);
	for (;;) {
		hWnd2 = FindWindow(NULL, "CHAT_CLIENT");
		if (hWnd2 == NULL) {
			SendMessage(hStory, LB_ADDSTRING, 0, (LPARAM)str);
			break;
		}

	}
	ReleaseDC(hWndMain, hdc);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {

	HDC hdc;
	COPYDATASTRUCT *pcds, cds;
	DWORD ThreadID;

	switch (iMessage) {
	case WM_CREATE:
		hWndMain = hWnd;
		hThread = CreateThread(NULL, 0, ThreadFunc, NULL, 0, &ThreadID);
		SuspendThread(hThread);

		hName = CreateWindow(TEXT("edit"),
			TEXT("�̰�ö"),
			WS_CHILD | WS_VISIBLE | WS_BORDER,
			0, 235, 75, 25,
			hWnd,
			(HMENU)ID_NAME,
			g_hInst,
			NULL);

		hList = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER,
			80, 235, 350, 25,
			hWnd,
			(HMENU)ID_LIST,
			g_hInst,
			NULL);

		hEnter = CreateWindow(TEXT("button"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
			435, 235, 45, 25,
			hWnd,
			(HMENU)ID_ENTER,
			g_hInst,
			NULL);

		hStory = CreateWindow(TEXT("listbox"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY,
			0, 1, 483, 230,
			hWnd,
			(HMENU)ID_STORY,
			g_hInst,
			NULL);

		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_ENTER:
			switch (HIWORD(wParam)) {
			case BN_CLICKED:
				GetWindowText(hName, str_name, 128);
				GetWindowText(hList, str_list, 128);

				wsprintf(str_story, "%s : %s", str_name, str_list);

				SendMessage(hStory, LB_ADDSTRING, 0, (LPARAM)str_story);

				SetWindowText(hList, "");

				cds.dwData = 0;
				cds.cbData = lstrlen(str_story);
				cds.lpData = str_story;
				hWnd2 = FindWindow(NULL, "CHAT_SERVER");
				if (hWnd2 != NULL)
					SendMessage(hWnd2, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&cds);

				break;
			}
		}

		return 0;

	case WM_COPYDATA:
		pcds = (PCOPYDATASTRUCT)lParam;
		hdc = GetDC(hWnd);
		SendMessage(hStory, LB_ADDSTRING, 0, (LPARAM)pcds->lpData);
		ReleaseDC(hWnd, hdc);
		return 0;

	case WM_DESTROY:
		CloseHandle(hThread);
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

