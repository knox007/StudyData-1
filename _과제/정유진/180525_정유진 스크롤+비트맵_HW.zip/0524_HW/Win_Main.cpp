#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("0504 Homework");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {

	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#define LISTBOX_ID1 100
#define COMBOBOX_ID1 101
#define SCR_RED 102
#define SCR_GREEN 103
#define SCR_BLUE 104
#define SCR_VERT 105
#define SRC_HORZ 106

TCHAR *Items1[] = { TEXT("����"), TEXT("�ڽ�"), TEXT("��"), TEXT("��Ʈ��") };
TCHAR *Items2[] = { TEXT("��"), TEXT("�귯��") };
HWND ListB, ComboB, ScrRed, ScrGreen, ScrBlue, EditB_R, EditB_G, EditB_B, Src_V, Src_H;
int Red1, Green1, Blue1, Red2, Green2, Blue2, SrcV, SrcH;
TCHAR text[128];
int idx1, idx2, Temp;

#include "resource.h"
LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	
	HDC hdc;
	PAINTSTRUCT ps;
	HBRUSH MyBrush, OldBrush;
	HPEN MyPen, OldPen;
	static HBITMAP MyBitmap, OldBitmap;
	int i;

	switch (iMessage) {
	case WM_CREATE:
		CreateWindow(TEXT("static"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE,
			30, 20, 100, 25,
			hWnd,
			(HMENU)0,	
			g_hInst,
			NULL);

		ListB = CreateWindow(TEXT("listbox"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY,	
			30, 40, 80, 80,
			hWnd,
			(HMENU)LISTBOX_ID1,
			g_hInst,
			NULL);
		for (i = 0; i<4; i++)
			SendMessage(ListB, LB_ADDSTRING, 0, (LPARAM)Items1[i]);
		
		CreateWindow(TEXT("static"),
			TEXT("����"),
			WS_CHILD | WS_VISIBLE,
			150, 20, 100, 25,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		ComboB = CreateWindow(TEXT("combobox"),
			NULL,
			WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,	
			150, 40, 80, 60,
			hWnd,
			(HMENU)COMBOBOX_ID1,
			g_hInst,
			NULL);
		for (i = 0; i<2; i++) 
			SendMessage(ComboB, CB_ADDSTRING, 0, (LPARAM)Items2[i]);	
			SendMessage(ComboB, CB_SETCURSEL, 0, 0);

		CreateWindow(TEXT("static"),
			TEXT("R"),
			WS_CHILD | WS_VISIBLE,
			260, 40, 100, 25,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		ScrRed = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,	
			280, 40, 400, 20,
			hWnd,
			(HMENU)SCR_RED,
			g_hInst,
			NULL);

		SetScrollRange(ScrRed, SB_CTL, 0, 255, TRUE);
		SetScrollPos(ScrRed, SB_CTL, 0, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("G"),
			WS_CHILD | WS_VISIBLE,
			260, 60, 100, 25,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		ScrGreen = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			280, 60, 400, 20,
			hWnd,
			(HMENU)SCR_GREEN,
			g_hInst,
			NULL);
		SetScrollRange(ScrGreen, SB_CTL, 0, 255, TRUE);
		SetScrollPos(ScrGreen, SB_CTL, 0, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("B"),
			WS_CHILD | WS_VISIBLE,
			260, 80, 100, 25,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		ScrBlue = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			280, 80, 400, 20,
			hWnd,
			(HMENU)SCR_BLUE,
			g_hInst,
			NULL);
		SetScrollRange(ScrBlue, SB_CTL, 0, 255, TRUE);
		SetScrollPos(ScrBlue, SB_CTL, 0, TRUE);

		EditB_R = CreateWindow(TEXT("edit"),
			NULL,			
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			690, 40, 50, 20,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);
		SetWindowText(EditB_R, "0");

		EditB_G = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			690, 60, 50, 20,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);
		SetWindowText(EditB_G, "0");

		EditB_B = CreateWindow(TEXT("edit"),
			NULL,
			WS_CHILD | WS_VISIBLE | WS_BORDER | ES_READONLY,
			690, 80, 50, 20,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);
		SetWindowText(EditB_B, "0");

		Src_H = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			30, 400, 710, 20,
			hWnd,
			(HMENU)SRC_HORZ,
			g_hInst,
			NULL);

		SetScrollRange(Src_H, SB_CTL, 0, 255, TRUE);
		SetScrollPos(Src_H, SB_CTL, 0, TRUE);

		Src_V = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_VERT,
			720, 100, 20, 300,
			hWnd,
			(HMENU)SCR_VERT,
			g_hInst,
			NULL);

		SetScrollRange(Src_V, SB_CTL, 0, 255, TRUE);
		SetScrollPos(Src_V, SB_CTL, 0, TRUE);

		MyBitmap = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));

		return 0;

	case WM_HSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINELEFT:
			Temp = max(0, Temp - 1);
			break;
		case SB_LINERIGHT:
			Temp = min(255, Temp + 1);
			break;
		case SB_PAGELEFT:
			Temp = max(0, Temp - 10);
			break;
		case SB_PAGERIGHT:
			Temp = min(255, Temp + 10);
			break;
		case SB_THUMBTRACK:
			Temp = HIWORD(wParam);
			break;
		}

		if ((HWND)lParam == ScrRed && idx2 == 0) {
			Red1 = Temp;
			wsprintf(text, TEXT("%d"), Red1);
			SetWindowText(EditB_R, text);
		} else if ((HWND)lParam == ScrGreen && idx2 == 0) {
			Green1 = Temp;
			wsprintf(text, TEXT("%d"), Green1);
			SetWindowText(EditB_G, text);
		} else if ((HWND)lParam == ScrBlue && idx2 == 0) {
			Blue1 = Temp;
			wsprintf(text, TEXT("%d"), Blue1);
			SetWindowText(EditB_B, text);
		} else if ((HWND)lParam == ScrRed && idx2 == 1) {
			Red2 = Temp;
			wsprintf(text, TEXT("%d"), Red2);
			SetWindowText(EditB_R, text);
		} else if ((HWND)lParam == ScrGreen && idx2 == 1) {
			Green2 = Temp;
			wsprintf(text, TEXT("%d"), Green2);
			SetWindowText(EditB_G, text);
		} else if ((HWND)lParam == ScrBlue && idx2 == 1) {
			Blue2 = Temp;
			wsprintf(text, TEXT("%d"), Blue2);
			SetWindowText(EditB_B, text);
		} else if ((HWND)lParam == Src_H) {
			SrcH = Temp;
		}
		SetScrollPos((HWND)lParam, SB_CTL, Temp, TRUE);
		InvalidateRect(hWnd, NULL, TRUE);

		return 0;

	case WM_VSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINEUP:
			Temp = max(0, Temp - 1);
			break;
		case SB_LINEDOWN:
			Temp = min(400, Temp + 1);
			break;
		case SB_PAGEUP:
			Temp = max(0, Temp - 10);
			break;
		case SB_PAGEDOWN:
			Temp = min(400, Temp + 10);
			break;
		case SB_THUMBTRACK:
			Temp = HIWORD(wParam);
			break;
		}

		SrcV = Temp;
		SetScrollPos((HWND)lParam, SB_CTL, Temp, TRUE);
		InvalidateRect(hWnd, NULL, TRUE);
		return 0;

	case WM_PAINT:
		HDC MemDC;

		hdc = BeginPaint(hWnd, &ps);

		MyBrush = CreateSolidBrush(RGB(Red2, Green2, Blue2));
		OldBrush = (HBRUSH)SelectObject(hdc, MyBrush);

		MyPen = CreatePen(PS_SOLID, 5, RGB(Red1, Green1, Blue1));
		OldPen = (HPEN)SelectObject(hdc, MyPen);

		MemDC = CreateCompatibleDC(hdc);

		if (idx1 == 0) {
			MoveToEx(hdc, 30 - SrcH, 120 - SrcV, NULL);
			LineTo(hdc, 680 - SrcH, 300 - SrcV);
		} else if (idx1 == 1) {
			Rectangle(hdc, 30 - SrcH, 120 - SrcV, 680 - SrcH, 300 - SrcV);
		} else if (idx1 == 2) {
			Ellipse(hdc, 30 - SrcH, 120 - SrcV, 680 - SrcH, 300 - SrcV);
		} else if (idx1 == 3) {
			OldBitmap = (HBITMAP)SelectObject(MemDC, MyBitmap);
			BitBlt(hdc, 0, 0, 648, 365, MemDC, 0, 0, SRCCOPY);
		}

		SelectObject(hdc, OldBrush);
		SelectObject(hdc, OldPen);
		DeleteObject(MyBrush);
		DeleteObject(MyPen);
		SelectObject(MemDC, OldBitmap);
		DeleteObject(MyBitmap);
		DeleteDC(MemDC);

		EndPaint(hWnd, &ps);
		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case LISTBOX_ID1:
			switch (HIWORD(wParam)) {
			case LBN_SELCHANGE:
				idx1 = SendMessage(ListB, LB_GETCURSEL, 0, 0);
			}
		case COMBOBOX_ID1:
			switch (HIWORD(wParam)) {
			case CBN_SELCHANGE:
				idx2 = SendMessage(ComboB, CB_GETCURSEL, 0, 0);
				if (idx2 == 0) {
					wsprintf(text, TEXT("%d"), Red1);
					SetWindowText(EditB_R, text);
					wsprintf(text, TEXT("%d"), Green1);
					SetWindowText(EditB_G, text);
					wsprintf(text, TEXT("%d"), Blue1);
					SetWindowText(EditB_B, text);
					SetScrollPos(ScrRed, SB_CTL, Red1, TRUE);
					SetScrollPos(ScrGreen, SB_CTL, Green1, TRUE);
					SetScrollPos(ScrBlue, SB_CTL, Blue1, TRUE);
				} else {
					wsprintf(text, TEXT("%d"), Red2);
					SetWindowText(EditB_R, text);
					wsprintf(text, TEXT("%d"), Green2);
					SetWindowText(EditB_G, text);
					wsprintf(text, TEXT("%d"), Blue2);
					SetWindowText(EditB_B, text);
					SetScrollPos(ScrRed, SB_CTL, Red2, TRUE);
					SetScrollPos(ScrGreen, SB_CTL, Green2, TRUE);
					SetScrollPos(ScrBlue, SB_CTL, Blue2, TRUE);
				}
			}
		}

		InvalidateRect(hWnd, NULL, TRUE);
		return 0;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
