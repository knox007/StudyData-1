//====================================================
#pragma once
#include "CObject.h"
//====================================================

class CView;
typedef void (CView::*CViewFuncPointer)();
typedef struct tagMessageMap {
	UINT iMsg;
	CViewFuncPointer fp;
}MessageMap;

static CViewFuncPointer fpCViewGlobal;

class CView : public CObject
{
public:
	static MessageMap messageMap[];
public:
	void OnCreate();
	void OnDraw();
	void OnDestroy();
	void OnLButtonDown();
};
//====================================================
extern CView g_View;
//====================================================
