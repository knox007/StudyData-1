//============================================
#include "Global.h"
//============================================
CMyGame::CMyGame()	{}
//============================================
CMyGame::~CMyGame()	{}
//============================================

//512 328
//64 82

RECT m_rcImage = { 0, 246, 64, 328 };
RECT mario_move[] = { { 0, 246, 64, 328 }, { 0, 164, 64, 246 }, { 128, 164, 192, 246 }, { 320, 246, 384, 328 } };
INT num = 0;

INT		CMyGame::Init()
{ 
	char* texture_name[] = { "texture/mario_tile1.png", "texture/mario_bush2.png", "texture/mario_bush1.png", "texture/mario_cloud.png", "texture/mario_all.png" };
	
	for (int i = 0; i < 5; i++) {
		if (FAILED(D3DXCreateTextureFromFileEx(
			m_pD3DDevice				
			, texture_name[i]			
			, D3DX_DEFAULT													
			, D3DX_DEFAULT				
			, 1							
			, 0
			, D3DFMT_UNKNOWN
			, D3DPOOL_MANAGED
			, D3DX_FILTER_NONE			
			, D3DX_FILTER_NONE			
			, 0							
			, &m_d3DImageInfo[i]		
			, NULL
			, &m_pD3DTxtr[i]
		)))
		{
			MessageBox(NULL, "file Could not be found", "Err", 0);
			m_pD3DTxtr[i] = NULL;
			return -1;
		}
	}
	
	m_dwBeginTime = timeGetTime();	//	�ü���� ���۵��� ����� �ð�.

	return 0;

}//	INT		CMyGame::Init()
//============================================
INT		CMyGame::Render()
{	
	// ����
	RECT rt_floor = { 0, 0, (LONG)m_d3DImageInfo[0].Width, (LONG)m_d3DImageInfo[0].Height };

	// ū ��
	RECT rt_big_tree = { 0, 0, (LONG)m_d3DImageInfo[1].Width, (LONG)m_d3DImageInfo[1].Height };

	// ���� ��
	RECT rt_small_tree = { 0, 0, (LONG)m_d3DImageInfo[2].Width, (LONG)m_d3DImageInfo[2].Height };

	// ����1
	RECT rt_sky1 = { 0, 0, 140, (LONG)m_d3DImageInfo[3].Height };

	// ����2
	RECT rt_sky2 = { 150, 0, (LONG)m_d3DImageInfo[3].Width, (LONG)m_d3DImageInfo[3].Height };

	// ������
	//RECT rt_mario = { 0, 246, 64, 328 };


	// ���� 3��
	for (int i = 500; i < 800; i+=128) {
		D3DXVECTOR3	vcPo3_floor3(i, 260, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[0], &rt_floor, NULL, &vcPo3_floor3, D3DXCOLOR(1, 1, 1, 1));
	}

	// ū ��
	for (int i = -50; i < 200; i += 150) {
		D3DXVECTOR3	vcPos_big_tree(i, 350, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[1], &rt_big_tree, NULL, &vcPos_big_tree, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� �� 2��
	for (int i = 500; i < 800; i += 100) {
		D3DXVECTOR3	vcPos_small_tree2(i, 340, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[2], &rt_small_tree, NULL, &vcPos_small_tree2, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� 2��
	for (int i = 280; i < 800; i+=128) {
		D3DXVECTOR3	vcPo3_floor2(i, 380, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[0], &rt_floor, NULL, &vcPo3_floor2, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� �� 1��
	for (int i = 280; i < 800; i+=100) {
		D3DXVECTOR3	vcPos_small_tree1(i, 440, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[2], &rt_small_tree, NULL, &vcPos_small_tree1, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� 1��
	for (int i = 0; i < 800; i+=128) {
		D3DXVECTOR3	vcPo3_floor1(i, 475, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[0], &rt_floor, NULL, &vcPo3_floor1, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� 1
	float sky1[] = { 550 };
	for (int i = 0; i < 1; i++) {
		D3DXVECTOR3	vcPo3_sky1(sky1[i], 30, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[3], &rt_sky1, NULL, &vcPo3_sky1, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� 2
	float sky2[] = { 130 };
	for (int i = 0; i < 1; i++) {
		D3DXVECTOR3	vcPo3_sky2(sky2[i], 120, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[3], &rt_sky2, NULL, &vcPo3_sky2, D3DXCOLOR(1, 1, 1, 1));
	}

	// ������
	float mario[] = { 350 };
	for (int i = 0; i < 1; i++) {
		D3DXVECTOR3	vcPo3_mario(mario[i], 300, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[4], &m_rcImage, NULL, &vcPo3_mario, D3DXCOLOR(1, 1, 1, 1));
	}

	return 0;
}
//============================================
INT		CMyGame::FrameMove()	
{ 
	m_dwEndTime = timeGetTime();

	if ((m_dwEndTime - m_dwBeginTime) > FRAME_REFRESH_TIME) {
		m_rcImage = mario_move[num];
		num ++;

		if (num > 3) {
			num = 0;
		}

		m_dwBeginTime = m_dwEndTime;
	}

	return 0; 
}
//============================================
void	CMyGame::Destroy()
{
	for (int i = 0; i < 5; i++) {
		SAFE_RELEASE(m_pD3DTxtr[i]);
	}

}//	void	CMyGame::Destroy()
//============================================
//*
LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:		
		{			
			break;
		}
	}

	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}
//*/
//============================================