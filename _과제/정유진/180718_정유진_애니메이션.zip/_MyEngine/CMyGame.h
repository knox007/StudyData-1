//============================================
#pragma once
//============================================
#ifndef _MYGAME_H_
#define _MYGAME_H_
//============================================
#include "Global.h"
//============================================
//class STextureInto 
//{
//	D3DXIMAGE_INFO		m_imageInfo;
//	LPDIRECT3DTEXTURE9	m_d3dTxtr;
//	RECT				m_rcImage;
//
//};// class STextureInto
//============================================
#define FRAME_REFRESH_TIME	100
//============================================
class CMyGame :	public CDxCore
{
public:
	CMyGame();
	virtual ~CMyGame();

	virtual INT		Init();
	virtual INT		Render();
	virtual INT		FrameMove();
	virtual void	Destroy();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);

	//	��ü ����
	LPDIRECT3DTEXTURE9	m_pD3DTxtr[5] = { NULL } ;

	// ���� Ÿ��
	DWORD				m_dwBeginTime;
	// �� Ÿ��
	DWORD				m_dwEndTime;

};// class CMyGame :	public CDxCore

extern CMyGame*	g_pApp;
//============================================
#endif // _MYGAME_H_
//============================================