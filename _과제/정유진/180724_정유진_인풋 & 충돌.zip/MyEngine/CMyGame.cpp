//============================================
#include "Global.h"
//============================================
CMyGame::CMyGame()	
{
	memset(m_MouseTxt, 0, sizeof(m_MouseTxt));
	memset(m_KeyboardTxt, 0, sizeof(m_KeyboardTxt));
}
//============================================
CMyGame::~CMyGame()	{}
//============================================
INT		CMyGame::Init()
{
	if (FAILED(m_dxTxtrTest.Create(m_pD3DDevice, "texture/myfamily.jpg")))
		return -1;

	if (FAILED(m_dxFont.Create(m_pD3DDevice, _T("����ü"), 20, FW_BOLD)))
	//if (FAILED(m_dxFont.Create(m_pD3DDevice, _T("����ü"), 20, FW_LIGHT)))
		return E_FAIL;

	m_pInputManager = new CInputManager();

	m_pInputManager->Create(m_hWnd);
	
	return 0;

}//	INT		CMyGame::Init()
//============================================
INT		CMyGame::Render()
{
	RECT rt;

	//	�̹��� ����
	m_dxTxtrTest.GetImageRect(&rt);
	LPDIRECT3DTEXTURE9 pTxTmp = m_dxTxtrTest.GetTexture();

	//	�̹��� �ʺ� & ����
	D3DXVECTOR3	vcCenter((LONG)m_dxTxtrTest.GetImageWidth() * 0.5f, (LONG)m_dxTxtrTest.GetImageHeight() * 0.5f, 0);
	D3DXVECTOR3	vcPos(m_dwScrWidth * 0.5f, m_dwScrHeight * 0.5f + Wheel, 0);
	m_pD3DSprite->Draw(pTxTmp, &rt, &vcCenter, &vcPos, D3DXCOLOR(1, 1, 1, 1));

	//	��Ʈ ���.
	m_dxFont.Draw(m_pD3DSprite, _T("�츮 ���� �Դϴ� ^^"), 0, 0 + Wheel, 300, 50, D3DXCOLOR(1, 1, 0, 1), DT_LEFT);


	// ���콺 ��ǥ
	sprintf(m_MouseTxt, "���콺 ��ǥ x : %f, y : %f", m_pInputManager->GetMousePos().x, m_pInputManager->GetMousePos().y);
	m_dxFont.Draw(m_pD3DSprite, m_MouseTxt, 0, 50 + Wheel, 500, 50, D3DXCOLOR(1, 0, 1, 1), DT_LEFT);

	//Ű���� 
	memset(m_KeyboardTxt, 0, sizeof(m_KeyboardTxt));
	for (int cnt = 0; cnt < 256; ++cnt)
	{
		if (m_pInputManager->KeyDown(cnt))
		{
			sprintf(m_KeyboardTxt, "Ű���� DOWN : %c", cnt, cnt);
			m_dxFont.Draw(m_pD3DSprite, m_KeyboardTxt, 0, 100, 220, 50, D3DXCOLOR(1, 0.2f, 0, 1), DT_LEFT);
		}
	}

	for (int cnt = 0; cnt < 256; ++cnt)
	{
		if (m_pInputManager->KeyUp(cnt))
		{
			sprintf(m_KeyboardTxt, "Ű���� Up : %c", cnt, cnt);
			m_dxFont.Draw(m_pD3DSprite, m_KeyboardTxt, 0, 200, 220, 50, D3DXCOLOR(1, 0.2f, 0, 1), DT_LEFT);
		}
	}

	for (int cnt = 0; cnt < 256; ++cnt)
	{
		if (m_pInputManager->KeyPress(cnt))
		{
			sprintf(m_KeyboardTxt, "Ű���� Press : %c", cnt, cnt);
			m_dxFont.Draw(m_pD3DSprite, m_KeyboardTxt, 0, 300, 220, 50, D3DXCOLOR(1, 0.2f, 0, 1), DT_LEFT);
		}
	}

	return 0;

}//	INT		CMyGame::Render()
//============================================
INT		CMyGame::FrameMove()
{
	if (m_pInputManager)
	{
		m_pInputManager->FrameMove();

		if (CInputManager::DBLCLK == m_pInputManager->BtnState(0))
		{
			TCHAR	sMsg[1024] = { 0 };
			sprintf(sMsg, _T("���콺 ���� ��ư ���� Ŭ��!!"));
			SetWindowText(m_hWnd, sMsg);
		}

		if (CInputManager::DBLCLK == m_pInputManager->BtnState(1))
		{
			TCHAR	sMsg[1024] = { 0 };
			sprintf(sMsg, _T("���콺 ���� ��ư ���� Ŭ��!!"));
			SetWindowText(m_hWnd, sMsg);
		}

		if (CInputManager::DBLCLK == m_pInputManager->BtnState(2))
		{
			TCHAR	sMsg[1024] = { 0 };
			sprintf(sMsg, _T("���콺 ��� ��ư ���� Ŭ��!!"));
			SetWindowText(m_hWnd, sMsg);
		}

		Wheel += m_pInputManager->GetMouseEps().z;
	}//	if (m_pInputManager)

	return 0;

}//	INT		CMyGame::FrameMove()
//============================================
void	CMyGame::Destroy()
{
	SAFE_DELETE(m_pInputManager);

	m_dxTxtrTest.Destroy();
	m_dxFont.Destroy();
}
//============================================
LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (m_pInputManager)
		m_pInputManager->MsgProc(hWnd, msg, wParam, lParam);

	switch (msg)
	{
	case WM_PAINT:
	{
		break;
	}
	}

	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}
