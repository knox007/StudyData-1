#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("0531 Homework");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#define ID_EFF 100
#define ID_BG 101
#define ID_COMBOBOX 102
#define ID_SCREEN 103

HWND hEff, hBg, hCombo, hChk;
int Eff_SCR, BG_SCR, RES, SCREEN, Temp;
char Dir[256] = { NULL, };
TCHAR *Items[] = { TEXT("800 * 600"), TEXT("1280 * 720"), TEXT("1600 * 900"), TEXT("1920 * 1080") };

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	
	TCHAR buf[10];
	int i;

	switch (iMessage) {
	case WM_CREATE:
		GetCurrentDirectory(256, Dir);
		strcat_s(Dir, "\\Setting.ini");

		Eff_SCR = GetPrivateProfileInt("Setting", "Eff_SCR", 0, Dir);
		BG_SCR = GetPrivateProfileInt("Setting", "BG_SCR", 0, Dir);
		RES = GetPrivateProfileInt("Setting", "RES", 0, Dir);
		SCREEN = GetPrivateProfileInt("Setting", "SCREEN", 0, Dir);

		CreateWindow(TEXT("static"),
			TEXT("Eff Sound"),
			WS_CHILD | WS_VISIBLE,
			20, 20, 100, 25,
			hWnd,
			(HMENU)-1,	
			g_hInst,
			NULL);

		hEff = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			120, 20, 300, 20,
			hWnd,
			(HMENU)ID_EFF,
			g_hInst,
			NULL);
		SetScrollRange(hEff, SB_CTL, 0, 10, TRUE);
		SetScrollPos(hEff, SB_CTL, Eff_SCR, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("BG Sound"),
			WS_CHILD | WS_VISIBLE,
			20, 60, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		hBg = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			120, 60, 300, 20,
			hWnd,
			(HMENU)ID_BG,
			g_hInst,
			NULL);
		SetScrollRange(hBg, SB_CTL, 0, 10, TRUE);
		SetScrollPos(hBg, SB_CTL, BG_SCR, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("�ػ�"),
			WS_CHILD | WS_VISIBLE,
			20, 100, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		hCombo = CreateWindow(TEXT("combobox"),
			NULL,
			WS_CHILD | WS_VISIBLE | CBS_DROPDOWN,
			120, 100, 120, 100,
			hWnd,
			(HMENU)ID_COMBOBOX,
			g_hInst,
			NULL);

		for (i = 0; i<4; i++)
			SendMessage(hCombo, CB_ADDSTRING, 0, (LPARAM)Items[i]);	

		SendMessage(hCombo, CB_SETCURSEL, RES, 0);

		CreateWindow(TEXT("static"),
			TEXT("��üȭ��"),
			WS_CHILD | WS_VISIBLE,
			20, 140, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		hChk = CreateWindow(TEXT("button"),
			TEXT("YES"),
			WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
			120, 140, 140, 25,
			hWnd,
			(HMENU)ID_SCREEN,
			g_hInst,
			NULL);

		if (SCREEN == 0) {
			SendMessage(hChk, BM_SETCHECK, BST_UNCHECKED, 0);
		} else {
			SendMessage(hChk, BM_SETCHECK, BST_CHECKED, 0);
		}

		return 0;

	case WM_HSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINELEFT:
			Temp = max(0, Temp - 1);
			break;
		case SB_LINERIGHT:
			Temp = min(10, Temp + 1);
			break;
		case SB_PAGELEFT:
			Temp = max(0, Temp - 2);
			break;
		case SB_PAGERIGHT:
			Temp = min(10, Temp + 2);
			break;
		case SB_THUMBTRACK:
			Temp = HIWORD(wParam);
			break;
		}

		if ((HWND)lParam == hEff)
			Eff_SCR = Temp;
		else
			BG_SCR = Temp;

		SetScrollPos((HWND)lParam, SB_CTL, Temp, TRUE);
		InvalidateRect(hWnd, NULL, TRUE);

		return 0;

	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case ID_COMBOBOX:
			switch (HIWORD(wParam)) {
			case CBN_SELCHANGE:			
				RES = SendMessage(hCombo, CB_GETCURSEL, 0, 0);
				break;
			}
		case ID_SCREEN:
			if (SendMessage(hChk, BM_GETCHECK, 0, 0) == BST_UNCHECKED) {
				SCREEN = 0;
			} else {
				SCREEN = 1;
			}
			break;
		}
		return 0;

	case WM_DESTROY:
		_itoa_s(Eff_SCR, buf, 10);
		WritePrivateProfileString("Setting", "Eff_SCR", buf, Dir);
		_itoa_s(BG_SCR, buf, 10);
		WritePrivateProfileString("Setting", "BG_SCR", buf, Dir);
		_itoa_s(RES, buf, 10);
		WritePrivateProfileString("Setting", "RES", buf, Dir);
		_itoa_s(SCREEN, buf, 10);
		WritePrivateProfileString("Setting", "SCREEN", buf, Dir);

		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}


