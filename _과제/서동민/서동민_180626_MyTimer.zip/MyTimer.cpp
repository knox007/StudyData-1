#include <windows.h>
#include<time.h>
#include<atlstr.h>
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass=TEXT("MyGame");

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance
		  ,LPSTR lpszCmdParam,int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst=hInstance;
	
	WndClass.cbClsExtra=0;
	WndClass.cbWndExtra=0;
	WndClass.hbrBackground=(HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor=LoadCursor(NULL,IDC_ARROW);
	WndClass.hIcon=LoadIcon(NULL,IDI_APPLICATION);
	WndClass.hInstance=hInstance;
	WndClass.lpfnWndProc=WndProc;
	WndClass.lpszClassName=lpszClass;
	WndClass.lpszMenuName=NULL;
	WndClass.style=CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd=CreateWindow(lpszClass,lpszClass,WS_OVERLAPPEDWINDOW,
		  CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,
		  NULL,(HMENU)NULL,hInstance,NULL);
	ShowWindow(hWnd,nCmdShow);
	
	while (GetMessage(&Message,NULL,0,0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}
/*
UINT SetTimer( HWND hWnd, UINT nIDEvent, UINT uElapse, TIMERPROC lpTimerFunc)
	
	hWnd		:	Ÿ�̸� �޽����� ���� ������.
					���� WndProc�� hWnd�� �״�� ���.
	
	nIDEvent	:	Ÿ�̸��� ID.

	uElapse		:	Ÿ�̸��� �ֱ�.
					������ 1/1000��.
					�� ���� 1�̶�� �ؼ� Ÿ�̸� �޽����� �ʴ� 1000�� �߻����� �ʴ´�.
					1�ʿ� 100ȸ �̻� �߻����� ����.

	lpTimerFunc	:	Ÿ�̸� �޽����� �߻��Ҷ� ���� ȣ��� �Լ�.



*/

int  score = 1;//����
int second = 25;//��
CString str;
int posX = 10;
int posY = 10;
int drt = 1;
int i = 2;
CString str2;
void Init()
{
	str.Format(_T("%d"), score);
	str2.Format(_T("%d"), second);
	score = 1;
	second = 25;
	posX = 10;
	posY = 10;
	drt = 1;
	i = 2;
}

LRESULT CALLBACK WndProc(HWND hWnd,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	HDC hdc;
	
	int touch = 15;// ��ġ ����
	PAINTSTRUCT ps;
	SYSTEMTIME st;
	int speed[] = { 5,10,15,12,25 };
	static TCHAR sTime[128] = "��";
	static RECT rt={100,100,400,120};
	POINT mousePos;
	
		switch (iMessage)
		{
		case WM_CREATE:
			srand(time(0));
			SetTimer(hWnd, 1, 100, NULL);
			SetTimer(hWnd, 2, 1500, NULL);
			SetTimer(hWnd, 3, 1900, NULL);
			SetTimer(hWnd, 4, 1000, NULL);
			Init();
			return 0;
		case WM_TIMER:
			switch (wParam)
			{
			case 1:
			{
				switch (drt)
				{
				case 0:
				{
					posY -= speed[i];
					if (posY <= 0)
					{
						drt = 2;
					}
					break;
				}
				case 1:
				{
					posX += speed[i];
					if (posX >= 1000)
					{
						drt = 3;
					}
					break;
				}
				case 2:
				{
					posY += speed[i];
					if (posY >= 700)
					{
						drt = 0;
					}
					break;
				}
				case 3:
				{
					posX -= speed[i];
					if (posX <= 0)
					{
						drt = 1;
					}
					break;
				}
				break;
				}//	switch (drt)
			}//	case 1:
			break;

			case 2: {
				drt = rand() % 4;
				break;
			}
			case 3:
			{
				i = rand() % 5;
				break;
			}
			case 4:
			{
				second--;
				str2.Format(_T("%d"), second);
				break;
			}
			}//	switch (wParam)
			InvalidateRect(hWnd, NULL, TRUE);
			return 0;
		case WM_LBUTTONDOWN:
		{
			int X = LOWORD(lParam);
			int Y = HIWORD(lParam);
			if (posX - touch < X && posX + touch > X && posY - touch < Y && posY + touch > Y) {
				score--;
				str.Format(_T("%d"), score);
				if (score < 0)
					score = 0;
			}
			/*
			str.Format(_T("X = %d,Y = %d"), X, Y);
			MessageBox(hWnd, str, "�׽�Ʈ", MB_OK);
			//*/
		}
		return 0;
		case WM_PAINT:
			hdc = BeginPaint(hWnd, &ps);
			TextOut(hdc, posX, posY, sTime, lstrlen(sTime));
			TextOut(hdc, 900, 10, str, lstrlen(str));
			TextOut(hdc, 900, 30, str2, lstrlen(str2));

			if (second < 1)
			{
				if (score == 0) {
					str2 = "����";
					TextOut(hdc, 900, 30, str2, lstrlen(str2));
					KillTimer(hWnd, 1);
					KillTimer(hWnd, 2);
					KillTimer(hWnd, 3);
					KillTimer(hWnd, 4);
					if (MessageBox(hWnd, "�ٽ��Ͻðڽ��ϱ�?", "����", MB_YESNO) == IDYES) {
						SendMessage(hWnd, WM_CREATE, 0, 0);
						Init();
					}
					else {
						MessageBox(hWnd, "�����մϴ�", "����", MB_OK);
						PostQuitMessage(0);
					}
				}
				else {
					str2 = "����";
					TextOut(hdc, 900, 30, str2, lstrlen(str2));
					KillTimer(hWnd, 1);
					KillTimer(hWnd, 2);
					KillTimer(hWnd, 3);
					KillTimer(hWnd, 4);
					if (MessageBox(hWnd, "�ٽ��Ͻðڽ��ϱ�?", "����", MB_YESNO) == IDYES) {
						SendMessage(hWnd, WM_CREATE, 0, 0);
						Init();
					}
					else {
						MessageBox(hWnd, "�����մϴ�", "����", MB_OK);
						PostQuitMessage(0);
					}
				}

			}//	if (second < 1)
			else
			{
				if (score == 0) {
					str2 = "����";
					TextOut(hdc, 900, 30, str2, lstrlen(str2));
					KillTimer(hWnd, 1);
					KillTimer(hWnd, 2);
					KillTimer(hWnd, 3);
					KillTimer(hWnd, 4);
					if (MessageBox(hWnd, "�ٽ��Ͻðڽ��ϱ�?", "����", MB_YESNO) == IDYES) {
						SendMessage(hWnd, WM_CREATE, 0, 0);
						Init();
					}
					else {
						MessageBox(hWnd, "�����մϴ�", "����", MB_OK);
						PostQuitMessage(0);
					}
				}
			}



			EndPaint(hWnd, &ps);
			return 0;
		case WM_DESTROY:
			KillTimer(hWnd, 1);
			KillTimer(hWnd, 2);
			KillTimer(hWnd, 3);
			KillTimer(hWnd, 4);
			PostQuitMessage(0);
			return 0;
		}

		return(DefWindowProc(hWnd, iMessage, wParam, lParam));
	
}
