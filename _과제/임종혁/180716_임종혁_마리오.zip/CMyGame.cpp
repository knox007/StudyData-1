//============================================
#include "Global.h"
//============================================
CMyGame::CMyGame()	{}
//============================================
CMyGame::~CMyGame()	{}
//============================================
INT		CMyGame::Init()			
{ 
	char* Mario[] = { "Texture/mario_all.png", "Texture/mario_bush1.png", "Texture/mario_bush2.png", "Texture/mario_cloud.png", "Texture/mario_tile1.png" };

	for (int i=0; i < 5; i++)
	{
		if (FAILED(D3DXCreateTextureFromFileEx(
			m_pD3DDevice
			, Mario[i]
			, D3DX_DEFAULT
			, D3DX_DEFAULT
			, 1
			, 0
			, D3DFMT_UNKNOWN
			, D3DPOOL_MANAGED
			, D3DX_FILTER_NONE
			, D3DX_FILTER_NONE
			, 0
			, &m_d3DImageInfo
			, NULL
			, &m_pD3DTxtr[i]
			)))
		{
			MessageBox(NULL, "Texture/mario_all.png file Could not be found", "Err", 0);
			m_pD3DTxtr[i] = NULL;
			return -1;
		}

		SetRect(&m_tInfoBG.m_rcImage, 0, 0, m_tInfoBG.m_imageInfo.Width, m_tInfoBG.m_imageInfo.Height);

		if (FAILED(D3DXCreateTextureFromFileEx(
			m_pD3DDevice
			, "Texture/mario_all.png"
			, D3DX_DEFAULT
			, D3DX_DEFAULT
			, 1
			, 0
			, D3DFMT_UNKNOWN
			, D3DPOOL_MANAGED
			, D3DX_FILTER_NONE
			, D3DX_FILTER_NONE
			, 0
			, &m_tInfoAni.m_imageInfo
			, NULL
			, &m_tInfoAni.m_d3dTxtr
		)))
		{
			MessageBox(NULL, "Texture/mario_all.png file Could not be found", "Err", 0);
			m_tInfoAni.m_d3dTxtr = NULL;
			return -1;
		}
		SetRect(&m_tInfoAni.m_rcImage, 0, 0, 54, 84);
		m_dwBeginTime = timeGetTime();
	}
	return 0; 
}
//============================================
INT		CMyGame::Render()		
{ 
	RECT rtClound = {0,0,138,172};
	D3DXVECTOR3	vcLeftTop((LONG)m_d3DImageInfo.Width * 0.5f, (LONG)m_d3DImageInfo.Height * 0.5f, 0);
	D3DXVECTOR3	vcPos1(400 * 0.4f, 100 * 0.4f, 0);
	D3DXVECTOR3	vcPos2(800 * 0.4f, 50 * 0.4f, 0);
	m_pD3DSprite->Draw(m_pD3DTxtr[3], &rtClound, NULL, &vcPos1, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[3], &rtClound, NULL, NULL, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[3], &rtClound, NULL, &vcPos2, D3DXCOLOR(1, 1, 1, 1));

	RECT rtClound1 = {-460,-50,344,128};
	D3DXVECTOR3	vcCnter((LONG)m_d3DImageInfo.Width * 0.5f, (LONG)m_d3DImageInfo.Height * 0.5f, 0);
	D3DXVECTOR3	vcPos3(205 * 0.4f, 122 * 0.4f, 0);
	m_pD3DSprite->Draw(m_pD3DTxtr[3], &rtClound1, NULL, NULL, D3DXCOLOR(1, 1, 1, 1));

	RECT rtTail = {0,-472,128,128 };
	D3DXVECTOR3 vcDonw((LONG)m_d3DImageInfo.Width * 0.5f, (LONG)m_d3DImageInfo.Height * 0.5f, 0);
	D3DXVECTOR3 vcPos4(128 * 0.4f, 128 * 0.4f, 0);
	D3DXVECTOR3 vcPos5(320 * 0.4f, 0, 0);
	D3DXVECTOR3 vcPos6(650 * 0.4f, 0, 0);
	D3DXVECTOR3 vcPos7(600 * 0.4f, 0, 0);
	D3DXVECTOR3 vcPos8(700 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos9(800 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos10(900 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos11(1000 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos12(1100 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos13(1200 * 0.5f, 0, 0);
	D3DXVECTOR3 vcPos14(1400 * 0.5f, 0, 0);

	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, NULL, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos5, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos6, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos7, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos8, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos9, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos10, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos11, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos12, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos13, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &rtTail, NULL, &vcPos14, D3DXCOLOR(1, 1, 1, 1));

	RECT rtBlush2 = { 0,0,276,156 };
	D3DXVECTOR3 vcDown1((LONG)m_d3DImageInfo.Width * 0.5f, (LONG)m_d3DImageInfo.Height*0.5f, 0);
	D3DXVECTOR3 vcPos18(500, 383, 0);

	m_pD3DSprite->Draw(m_pD3DTxtr[2], &rtBlush2, &vcDown1, &vcPos18, D3DXCOLOR(1, 1, 1, 1));

	RECT rtBlush1 = { 0,0, 132,42 };
	D3DXVECTOR3 vcDown((LONG)m_d3DImageInfo.Width * 0.7f, (LONG)m_d3DImageInfo.Height * 0.5f, 0);
	D3DXVECTOR3 vcPos15(10, 432, 0);
	D3DXVECTOR3 vcPos16(300, 432, 0);
	D3DXVECTOR3 vcPos17(600, 432, 0);

	m_pD3DSprite->Draw(m_pD3DTxtr[1], &rtBlush1, NULL, &vcPos15, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[1], &rtBlush1, NULL, &vcPos16, D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_pD3DTxtr[1], &rtBlush1, NULL, &vcPos17, D3DXCOLOR(1, 1, 1, 1));

	

	m_pD3DSprite->Draw(m_tInfoBG.m_d3dTxtr, &m_tInfoBG.m_rcImage, &D3DXVECTOR3(m_tInfoBG.m_imageInfo.Width*0.5f, m_tInfoBG.m_imageInfo.Height*0.5f, 0), &D3DXVECTOR3(m_dwScrWidth*0.5f, m_dwScrHeight*0.5f, 0), D3DXCOLOR(1, 1, 1, 1));
	m_pD3DSprite->Draw(m_tInfoAni.m_d3dTxtr, &m_tInfoAni.m_rcImage, NULL, NULL, D3DXCOLOR(1, 1, 1, 1));
	return 0; 
}
//============================================
RECT mario_move[] = { { 0, 246, 64, 328 },{ 0, 164, 64, 246 },{ 128, 164, 192, 246 },{ 320, 246, 384, 328 } };
INT num = 0;
INT		CMyGame::FrameMove()	
{
	m_dwEndTime = timeGetTime();
	
	if ((m_dwEndTime - m_dwBeginTime) > FRAME_REFRESH_TIME)
	{
		m_tInfoAni.m_rcImage = mario_move[num];

		num++;
		if (num > 3)
			num = 0;

		/*
		m_tInfoAni.m_rcImage.left += 54;
		if (m_tInfoAni.m_rcImage.left + 54 >= 376)
			m_tInfoAni.m_rcImage.left = 0;

		m_tInfoAni.m_rcImage.right = m_tInfoAni.m_rcImage.left + 54;
		*/


		m_dwBeginTime = m_dwEndTime;
	}

	m_vecAniPos = D3DXVECTOR3(1, 0.95, 0.0f);
	m_vecAniPos *= 100;
	m_vecAniPos += D3DXVECTOR3(300, 300, 0.f);
	
	
	return 0;
}
//============================================
void	CMyGame::Destroy()		
{
	for (int i = 0; i < 5; i++)
	{
		SAFE_RELEASE(m_pD3DTxtr[i]);
	}
}
//============================================

LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
	case WM_PAINT:
	{
		break;
	}
	}
	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}