//================================================
#include "Global.h"
//================================================
CMyGame*	g_pMyGame;
//================================================
INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, INT)
{
	CMyGame	myGame;

	g_pMyGame = &myGame;

	if (FAILED(myGame.Create(hInst)))
		return -1;

	return myGame.Run();

}//	INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, INT)
//================================================