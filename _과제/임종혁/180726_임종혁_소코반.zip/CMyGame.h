//============================================
#pragma once
//============================================
#ifndef _MYGAME_H_
#define _MYGAME_H_
//============================================
#include "Global.h"
//============================================
class CMyGame :	public CDxCore
{
public:
	CMyGame();
	virtual ~CMyGame();

	virtual INT		Init();
	virtual INT		Render();
	virtual INT		FrameMove();
	virtual bool	SetNotIntersect(LPRECT pRect, CONST LPRECT pHold);
	virtual void	Destroy();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
	
	CDxTexture*		m_pDxTexture1;
	CDxTexture*		m_pDxTexture2;
	CDxTexture*		m_pDxTexture3;

	D3DXVECTOR3		m_vec3Pos1;	// ����
	D3DXVECTOR3		m_vec3Pos2; // �ڽ�
	D3DXVECTOR3		m_vec3Pos3; // ĳ����

	CDxFont			m_dxFont;

	LPDIRECT3DTEXTURE9 m_pD3DTxtr[5];

};// class CMyGame :	public CDxCore

extern CMyGame*	g_pApp;
//============================================
#endif // _MYGAME_H_
//============================================