//============================================
#include "Global.h"
//============================================
#define MOVEOFFSET	2.25F

#define P_Blank		0 // �����
#define P_Wall		1 // ��
#define P_Block		2 // ����
#define P_Player	3 // �÷��̾�
#define P_Hole		4 // ���ڱ���
//============================================
CMyGame::CMyGame()
{
	
}//	CMyGame::CMyGame()
//============================================
CMyGame::~CMyGame()	{}
//============================================

INT		CMyGame::Init()
{
	m_pDxTexture1 = new CDxTexture;
	if (FAILED(m_pDxTexture1->Create(m_pD3DDevice, "texture/Box.png")))
		return -1;

	m_pDxTexture2 = new CDxTexture;
	if (FAILED(m_pDxTexture2->Create(m_pD3DDevice, "texture/Brick.png")))
		return -1;

	m_pDxTexture3 = new CDxTexture;
	if (FAILED(m_pDxTexture3->Create(m_pD3DDevice, "texture/Mario.png")))
		return -1;
	
	if (FAILED(m_dxFont.Create(m_pD3DDevice, _T("�ü�ü"), 20, FW_BOLD)))
		return E_FAIL;

	m_vec3Pos1 = D3DXVECTOR3(40, 30, 0);
	m_vec3Pos2 = D3DXVECTOR3(100, 300,0);
	m_vec3Pos3 = D3DXVECTOR3(50, 300, 0);
	
	m_pInputManager = new CInputManager();
	m_pInputManager->Create(m_hWnd);
	
	return 0;

}//	INT		CMyGame::Init()
//============================================

int StageHeight = 9;
int StageWidth = 11;

//============================================
INT		CMyGame::Render()
{
	RECT	rcBox;
	RECT	rcBrick;
	RECT	rcMario;
	
	char map[9] [11] =
	{
		{1,1,1,1,1,1,1,1,1,1,1},
		{1,1,1,1,4,1,1,1,1,1,1},
		{1,1,1,1,0,1,1,1,1,1,1},
		{1,1,1,0,2,0,0,2,0,4,1},
		{1,4,0,2,0,3,0,1,1,1,1},
		{1,1,1,1,0,2,0,1,1,1,1},
		{1,1,1,1,0,1,1,1,1,1,1},
		{1,1,1,1,4,1,1,1,1,1,1},
		{1,1,1,1,1,1,1,1,1,1,1}
	};

	int i, j;

	LPDIRECT3DTEXTURE9 tmpTxture;
	LPDIRECT3DTEXTURE9 tmpTxture1;
	LPDIRECT3DTEXTURE9 tmpTxture2;

	for (i = 0; i < 9; i++)
	{
		for (j = 0; j < 11; j++)
		{
			tmpTxture = NULL;
			tmpTxture1 = NULL;
			tmpTxture2 = NULL;

			if (map[i][j] == 1)
			{
				m_pDxTexture2->GetImageRect(&rcBrick);
				tmpTxture = m_pDxTexture2->GetTexture();
			}

			else if (map[i][j] == 2)
			{
				m_pDxTexture1->GetImageRect(&rcBox);
				tmpTxture1 = m_pDxTexture1->GetTexture();
			}

			else if (map[i][j] == 3)
			{
				m_pDxTexture3->GetImageRect(&rcMario);
				tmpTxture2 = m_pDxTexture3->GetTexture();
			}

			D3DXVECTOR3 tmp = m_vec3Pos2;
			tmp.x += i * rcBrick.right;
			tmp.y += j * rcBrick.bottom;

			D3DXVECTOR3 tmp1 = m_vec3Pos1;
			tmp1.x += i * rcBox.right;
			tmp1.y += j * rcBox.bottom;

			D3DXVECTOR3 tmp2 = m_vec3Pos3;
			tmp2.x += i * rcBox.right;
			tmp2.y += j * rcBox.bottom;

			if(tmpTxture)
				m_pD3DSprite->Draw(tmpTxture,&rcBrick, NULL, &tmp, D3DXCOLOR(1, 1, 1, 1));

			else if (tmpTxture1)
				m_pD3DSprite->Draw(tmpTxture1, &rcBox, NULL, &tmp, D3DXCOLOR(1, 1, 1, 1));

			else if(tmpTxture2)
				m_pD3DSprite->Draw(tmpTxture2, &rcMario, NULL, &tmp, D3DXCOLOR(1, 1, 1, 1));
		}
	}

	return 0;

}//	INT		CMyGame::Render()
//============================================
INT		CMyGame::FrameMove()
{
	RECT	rcInter;

	if (m_pInputManager)
	{
		m_pInputManager->FrameMove();

		D3DXVECTOR3 tmpPos = m_vec3Pos3;

		//--------------------------------------
		//	��Ʈ��
		if (m_pInputManager->KeyPress(VK_RIGHT))
			tmpPos.x += MOVEOFFSET;

		if (m_pInputManager->KeyPress(VK_LEFT))
			tmpPos.x -= MOVEOFFSET;

		if (m_pInputManager->KeyPress(VK_UP))
			tmpPos.y -= MOVEOFFSET;

		if (m_pInputManager->KeyPress(VK_DOWN))
			tmpPos.y += MOVEOFFSET;

		//--------------------------------------
		//	�浹���� ����
		RECT rcCol1;
		SetRect(&rcCol1, INT(tmpPos.x)
			, INT(tmpPos.y)
			, INT(tmpPos.x) + m_pDxTexture3->GetImageWidth()
			, INT(tmpPos.y) + m_pDxTexture3->GetImageHeight()
		);

		RECT rcCol2;
		SetRect(&rcCol2
			, INT(m_vec3Pos2.x)
			, INT(m_vec3Pos2.y)
			, INT(m_vec3Pos2.x) + m_pDxTexture1->GetImageWidth()
			, INT(m_vec3Pos2.y) + m_pDxTexture1->GetImageHeight()
		);

		//--------------------------------------
		//	�浹 üũ
		
		bool isCollision = SetNotIntersect(&rcCol2, &rcCol1);

		m_vec3Pos3.x = rcCol2.left;
		m_vec3Pos3.y = rcCol2.top;
		
		//--------------------------------------
		//	�浹 ����� ���� ���ۼ���.
		if (!isCollision)
		{
			SetWindowText(m_hWnd, "����Ű�� ������ �ڽ��� �����Դϴ�.");
		}
		else
			SetWindowText(m_hWnd, "�浹!!!");
		m_vec3Pos3 = tmpPos;

	}//	if (m_pInputManager)

	return 0;

}//	INT		CMyGame::FrameMove()
//===========================================================================
bool CMyGame::SetNotIntersect(LPRECT pRect, CONST LPRECT pHold)
{
	RECT rcInter;

	if (IntersectRect(&rcInter, pRect, pHold))
	{
		int nInterW = rcInter.right - rcInter.left;
		int nInterH = rcInter.bottom - rcInter.top;

		if (nInterW > nInterH)
		{
			if (rcInter.top == pHold->top)
			{
				pRect->top -= nInterH;
				pRect->bottom -= nInterH;
			}

			else if (rcInter.bottom == pHold->bottom)
			{
				pRect->top += nInterH;
				pRect->bottom += nInterH;
			}
		}

		else
		{
			if (rcInter.left == pHold->left)
			{
				pRect->left -= nInterW;
				pRect->right -= nInterW;
			}

			else if (rcInter.right == pHold->right)
			{
				pRect->left += nInterW;
				pRect->right += nInterW;
			}
		}

		return true;
	}

	return false;
}
//=================================================================
void	CMyGame::Destroy()
{
	SAFE_DELETE(m_pDxTexture1);
	SAFE_DELETE(m_pDxTexture2);
	SAFE_DELETE(m_pDxTexture3);

	SAFE_DELETE(m_pInputManager);

	m_dxFont.Destroy();
}
//============================================
LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (m_pInputManager)
		m_pInputManager->MsgProc(hWnd, msg, wParam, lParam);

	switch (msg)
	{
		case WM_PAINT:
		{
			break;
		}
	}

	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}