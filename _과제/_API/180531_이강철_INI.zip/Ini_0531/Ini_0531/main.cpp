#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("Registry");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance
	, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

HWND Effect_scroll, Bg_scroll, Combo, Check;
int TempPos;
int Ini_eff, Ini_bg, Ini_resolution, Ini_full;
TCHAR CTemp[128];
char szCurDir[256] = { NULL, };

#define DEF_EFF_SCROLL 201
#define DEF_BG_SCROLL  202
#define DEF_COMBO_BOX  202
#define DEF_CHECK_BOX  203

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_CREATE:
		GetCurrentDirectory(256, szCurDir);
		strcat_s(szCurDir, "\\jackie.ini");

		Ini_eff = GetPrivateProfileInt("Set", "effect_sound", 0, szCurDir);
		Ini_bg = GetPrivateProfileInt("Set", "background", 0, szCurDir);
		Ini_resolution = GetPrivateProfileInt("Set", "resolution", 0, szCurDir);
		Ini_full = GetPrivateProfileInt("Set", "full_screen", 0, szCurDir);

		CreateWindow(TEXT("static"),
			TEXT("effect sound"),
			WS_CHILD | WS_VISIBLE | ES_CENTER,
			20, 20, 100, 25,
			hWnd,
			(HMENU)-1,	
			g_hInst,
			NULL);

		Effect_scroll = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,	
			150, 20, 300, 25,
			hWnd,
			(HMENU)DEF_EFF_SCROLL,
			g_hInst,
			NULL);
		SetScrollRange(Effect_scroll, SB_CTL, 0, 10, TRUE);
		SetScrollPos(Effect_scroll, SB_CTL, Ini_eff, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("background"),
			WS_CHILD | WS_VISIBLE | ES_CENTER,
			20, 50, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		Bg_scroll = CreateWindow(TEXT("scrollbar"),
			NULL,
			WS_CHILD | WS_VISIBLE | SBS_HORZ,
			150, 50, 300, 25,
			hWnd,
			(HMENU)DEF_BG_SCROLL,
			g_hInst,
			NULL);
		SetScrollRange(Bg_scroll, SB_CTL, 0, 10, TRUE);
		SetScrollPos(Bg_scroll, SB_CTL, Ini_bg, TRUE);

		CreateWindow(TEXT("static"),
			TEXT("�ػ�"),
			WS_CHILD | WS_VISIBLE | ES_CENTER,
			20, 80, 100, 25,
			hWnd,
			(HMENU)-1,
			g_hInst,
			NULL);

		Combo = CreateWindow(TEXT("combobox"),
			NULL,
			WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST,
			150, 80, 300, 100,
			hWnd,
			(HMENU)DEF_COMBO_BOX,
			g_hInst,
			NULL);

		SendMessage(Combo, CB_ADDSTRING, 0, (LPARAM)TEXT("800 * 600"));
		SendMessage(Combo, CB_ADDSTRING, 0, (LPARAM)TEXT("1280 * 720"));
		SendMessage(Combo, CB_ADDSTRING, 0, (LPARAM)TEXT("1600 * 900"));
		SendMessage(Combo, CB_ADDSTRING, 0, (LPARAM)TEXT("1920 * 1080"));
		SendMessage(Combo, CB_SETCURSEL, Ini_resolution, 0);
		
		Check = CreateWindow(TEXT("button"),
			TEXT("��ü ȭ��"),
			WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,	
			80, 110, 300, 25,
			hWnd,
			(HMENU)DEF_CHECK_BOX,
			g_hInst,
			NULL);

		if (Ini_full == 0) {
			SendMessage(Check, BM_SETCHECK, BST_UNCHECKED, 0);
		} else {
			SendMessage(Check, BM_SETCHECK, BST_CHECKED, 0);
		}

		return 0;
	case WM_HSCROLL:
		switch (LOWORD(wParam)) {
		case SB_LINELEFT:
			TempPos = max(0, TempPos - 1);
			break;
		case SB_LINERIGHT:
			TempPos = min(10, TempPos + 1);
			break;
		case SB_PAGELEFT:
			TempPos = max(0, TempPos - 1);
			break;
		case SB_PAGERIGHT:
			TempPos = min(10, TempPos + 1);
			break;
		case SB_THUMBTRACK:
			TempPos = HIWORD(wParam);
			break;
		}
		
		if ((HWND)lParam == Effect_scroll) {
			Ini_eff = TempPos;
		} else if ((HWND)lParam == Bg_scroll) {
			Ini_bg = TempPos;
		}

		SetScrollPos((HWND)lParam, SB_CTL, TempPos, TRUE);
		InvalidateRect(hWnd, NULL, FALSE);
		return 0;
	case WM_COMMAND:
		switch (LOWORD(wParam)) {
		case DEF_CHECK_BOX:
			if (SendMessage(Check, BM_GETCHECK, 0, 0) == BST_UNCHECKED) {
				Ini_full = 0;
			} else {
				Ini_full = 1;
			}
			break;
		case DEF_COMBO_BOX:
			switch (HIWORD(wParam)) {
			case CBN_SELCHANGE:
				Ini_resolution = SendMessage(Combo, CB_GETCURSEL, 0, 0);
				break;
			}
		}
		return 0;
	case WM_DESTROY:
		wsprintf(CTemp, TEXT("%d"), Ini_eff);
		WritePrivateProfileString("Set", "effect_sound", CTemp, szCurDir);
		wsprintf(CTemp, TEXT("%d"), Ini_bg);
		WritePrivateProfileString("Set", "background", CTemp, szCurDir);
		wsprintf(CTemp, TEXT("%d"), Ini_resolution);
		WritePrivateProfileString("Set", "resolution", CTemp, szCurDir);
		wsprintf(CTemp, TEXT("%d"), Ini_full);
		WritePrivateProfileString("Set", "full_screen", CTemp, szCurDir);
	
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

