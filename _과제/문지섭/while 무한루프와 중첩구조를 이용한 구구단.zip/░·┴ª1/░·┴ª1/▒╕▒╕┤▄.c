#pragma warning (disable: 4996)
#include <stdio.h>

int main(void)
{
	int num1 = 0;
	int num2 = 1;
	int res = num1 * num2;

	while (num1 != -1)
	{
		num2 = 1;

		printf("����� ���ڸ� �Է��ϼ���:\n");
		scanf("%d",&num1);

		printf("=======\n");
		printf("%d��\n",num1);
		printf("=======\n");

		while (num2 < 10)
		{
			printf("%d x %d = %d\n", num1, num2, res);
			num2++;
		}
	}
	return 0;
}