#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
HWND hWndMain;
LPCTSTR lpszClass = TEXT("MyButton");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
		NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

enum {
	LINE_BOLD = 101,
	RESET,
	LINE_BLACK,
	LINE_RED,
	LINE_BLUE,
	LINE_GREEN,
	SHAPE_LINE,
	SHAPE_SQUARE,
	SHAPE_ELLIPSE,
	SHAPE_BLACK,
	SHAPE_RED,
	SHAPE_BLUE,
	SHAPE_GREEN
};

HWND check_box;
COLORREF line_color = RGB(0, 0, 0), shape_color = RGB(0, 0, 0);
BOOL line_check = TRUE, square_check = FALSE, ellipse_check = FALSE, line_flag = FALSE, square_flag = FALSE, ellipse_flag = FALSE;
int line_width, line_x, line_y, shape_sx, shape_sy, shape_ex, shape_ey;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;

	switch (iMessage) {
	case WM_CREATE:
		CreateWindow(TEXT("button"),
			TEXT("�� ����"),
			WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
			5, 5, 120, 50,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		check_box = CreateWindow(TEXT("button"),
			TEXT("�β���"),
			WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX | WS_GROUP,
			10, 20, 100, 25,
			hWnd,
			(HMENU)LINE_BOLD,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("�ʱ�ȭ"),
			WS_CHILD | WS_VISIBLE | BS_DEFPUSHBUTTON,
			15, 70, 100, 25,
			hWnd,
			(HMENU)RESET,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("�� ����"),
			WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
			150, 5, 120, 140,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("������"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
			155, 20, 100, 30,
			hWnd,
			(HMENU)LINE_BLACK,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("������"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			155, 50, 100, 30,
			hWnd,
			(HMENU)LINE_RED,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("�Ķ���"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			155, 80, 100, 30,
			hWnd,
			(HMENU)LINE_BLUE,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("���"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			155, 110, 100, 30,
			hWnd,
			(HMENU)LINE_GREEN,
			g_hInst,
			NULL);

		CheckRadioButton(hWnd, LINE_BLACK, LINE_GREEN, LINE_BLACK);

		CreateWindow(TEXT("button"),
			TEXT("�׸� ����"),
			WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
			300, 5, 120, 140,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("������"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
			305, 20, 100, 30,
			hWnd,
			(HMENU)SHAPE_BLACK,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("������"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			305, 50, 100, 30,
			hWnd,
			(HMENU)SHAPE_RED,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("�Ķ���"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			305, 80, 100, 30,
			hWnd,
			(HMENU)SHAPE_BLUE,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("���"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			305, 110, 100, 30,
			hWnd,
			(HMENU)SHAPE_GREEN,
			g_hInst,
			NULL);

		CheckRadioButton(hWnd, SHAPE_BLACK, SHAPE_GREEN, SHAPE_BLACK);

		CreateWindow(TEXT("button"),
			TEXT("���"),
			WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
			450, 5, 120, 140,
			hWnd,
			(HMENU)0,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("��"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
			455, 20, 100, 30,
			hWnd,
			(HMENU)SHAPE_LINE,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("�׸�"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			455, 50, 100, 30,
			hWnd,
			(HMENU)SHAPE_SQUARE,
			g_hInst,
			NULL);

		CreateWindow(TEXT("button"),
			TEXT("Ÿ��"),
			WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
			455, 80, 100, 30,
			hWnd,
			(HMENU)SHAPE_ELLIPSE,
			g_hInst,
			NULL);

		CheckRadioButton(hWnd, SHAPE_LINE, SHAPE_ELLIPSE, SHAPE_LINE);

		return 0;
	case WM_COMMAND://	��Ʈ���� ���� �޽��� ���޽� ȣ��Ǵ� �޽���.
		switch (LOWORD(wParam)) {	// ��Ʈ���� ID
		case LINE_BOLD:
			if (SendMessage(check_box, BM_GETCHECK, 0, 0) == BST_UNCHECKED) {
				line_width = 1;
			}
			else {
				line_width = 5;
			}
			break;
		case RESET:
			InvalidateRect(hWnd, NULL, TRUE);
			break;
		case LINE_BLACK:
			line_color = RGB(0, 0, 0);
			break;
		case LINE_RED:
			line_color = RGB(255, 0, 0);
			break;
		case LINE_BLUE:
			line_color = RGB(0, 0, 255);
			break;
		case LINE_GREEN:
			line_color = RGB(0, 255, 0);
			break;
		case SHAPE_BLACK:
			shape_color = RGB(0, 0, 0);
			break;
		case SHAPE_RED:
			shape_color = RGB(255, 0, 0);
			break;
		case SHAPE_BLUE:
			shape_color = RGB(0, 0, 255);
			break;
		case SHAPE_GREEN:
			shape_color = RGB(0, 255, 0);
			break;
		case SHAPE_LINE:
			line_check = TRUE;
			square_check = FALSE;
			ellipse_check = FALSE;
			break;
		case SHAPE_SQUARE:
			line_check = FALSE;
			square_check = TRUE;
			ellipse_check = FALSE;
			break;
		case SHAPE_ELLIPSE:
			line_check = FALSE;
			square_check = FALSE;
			ellipse_check = TRUE;
			break;
		}
		return 0;
	case WM_LBUTTONDOWN:
		if (line_check) {
			line_x = LOWORD(lParam);
			line_y = HIWORD(lParam);
			line_flag = TRUE;
			square_flag = FALSE;
			ellipse_flag = FALSE;
		}
		else if (square_check) {
			shape_sx = LOWORD(lParam);
			shape_sy = HIWORD(lParam);
			shape_ex = shape_sx;
			shape_ey = shape_sy;

			line_flag = FALSE;
			square_flag = TRUE;
			ellipse_flag = FALSE;
		}
		else if (ellipse_check) {
			shape_sx = LOWORD(lParam);
			shape_sy = HIWORD(lParam);
			shape_ex = shape_sx;
			shape_ey = shape_sy;

			line_flag = FALSE;
			square_flag = FALSE;
			ellipse_flag = TRUE;
		}
		return 0;
	case WM_MOUSEMOVE:
		if (line_flag) {
			HPEN Pen, oPen;

			hdc = GetDC(hWnd);
			Pen = CreatePen(PS_SOLID, line_width, line_color);
			oPen = (HPEN)SelectObject(hdc, Pen);
			MoveToEx(hdc, line_x, line_y, NULL);
			line_x = LOWORD(lParam);
			line_y = HIWORD(lParam);
			LineTo(hdc, line_x, line_y);
			ReleaseDC(hWnd, hdc);
			SelectObject(hdc, oPen);
			DeleteObject(oPen);
			DeleteObject(Pen);
		}
		else if (square_flag || ellipse_flag) {
			hdc = GetDC(hWnd);
			SetROP2(hdc, R2_NOT);
			SelectObject(hdc, GetStockObject(NULL_BRUSH));

			if (square_flag) {
				Rectangle(hdc, shape_ex, shape_ey, shape_sx, shape_sy);
			}
			else if (ellipse_flag) {
				Ellipse(hdc, shape_ex, shape_ey, shape_sx, shape_sy);
			}

			shape_ex = LOWORD(lParam);
			shape_ey = HIWORD(lParam);

			if (square_flag) {
				Rectangle(hdc, shape_ex, shape_ey, shape_sx, shape_sy);
			}
			else if (ellipse_flag) {
				Ellipse(hdc, shape_ex, shape_ey, shape_sx, shape_sy);
			}

			ReleaseDC(hWnd, hdc);
		}

		return 0;
	case WM_LBUTTONUP:
		if (square_flag || ellipse_flag) {
			HBRUSH Brush, oBrush;

			hdc = GetDC(hWnd);
			Brush = CreateSolidBrush(shape_color);
			oBrush = (HBRUSH)SelectObject(hdc, Brush);
			shape_ex = LOWORD(lParam);
			shape_ey = HIWORD(lParam);
			if (square_flag) {
				Rectangle(hdc, shape_sx, shape_sy, shape_ex, shape_ey);
			}
			else if (ellipse_flag) {
				Ellipse(hdc, shape_sx, shape_sy, shape_ex, shape_ey);
			}
			ReleaseDC(hWnd, hdc);
			SelectObject(hdc, oBrush);
			DeleteObject(oBrush);
			DeleteObject(Brush);
		}

		line_flag = FALSE;
		square_flag = FALSE;
		ellipse_flag = FALSE;
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}