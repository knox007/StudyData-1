//============================================
#include "Global.h"
//============================================
CMyGame::CMyGame()	{}
//============================================
CMyGame::~CMyGame()	{}
//============================================
INT		CMyGame::Init()
{ 
	char* texture_name[] = { "texture/mario_bush1.png", "texture/mario_bush2.png", "texture/mario_cloud.png", "texture/mario_tile1.png", "texture/mario_all.png" };
	
	for (int i = 0; i < 5; i++) {
		if (FAILED(D3DXCreateTextureFromFileEx(
			m_pD3DDevice				//	����̽� ������
			, texture_name[i]			//	�ؽ��� ���
			, D3DX_DEFAULT				//	����
			, D3DX_DEFAULT				//	����
			, 1							//	�Ӹ� ����*( ���� ���� )
			, 0
			, D3DFMT_UNKNOWN
			, D3DPOOL_MANAGED
			, D3DX_FILTER_NONE			//	���͸�
			, D3DX_FILTER_NONE			//	�� ���͸�
			, 0							//	�÷�Ű
			, &m_d3DImageInfo[i]		//	�ؽ��� ����
			, NULL
			, &m_pD3DTxtr[i]
		))) {
			MessageBox(NULL, "file Could not be found", "Err", 0);
			m_pD3DTxtr[i] = NULL;
			return -1;
		}
	}
	
	m_dwBeginTime = timeGetTime();	//	�ü���� ���۵��� ����� �ð�.

	return 0;

}//	INT		CMyGame::Init()
//============================================

int x = 0, x2 = 64;
RECT m_rt = { 384, 246, 448, 328 };

RECT right_rt[4] = { {0,0,64,82}, {64,0,128,82}, {128,0,192,82}, {192,0,256,82} };
RECT left_rt[4] = { { 256,0,320,82 },{ 320,0,384,82 },{ 384,0,448,82 },{ 448,0,512,82 } };
//RECT right_rt[2] = { {0,0,64,82}, {64,0,128,82} };
//RECT left_rt[2] = { { 256,0,320,82 },{ 320,0,384,82 } };
RECT up_rt;
RECT down_rt;

int pos_x = 50;
int pos_y = 400;
D3DXVECTOR3	vcPos2(pos_x, pos_y, 0);

INT		CMyGame::Render()
{	
	// ū Ǯ ��ġ
	float bush2_pos[] = { 10, 600 };		
	for (int i = 0; i < sizeof(bush2_pos) / sizeof(float); i++) {
		RECT rt = { 0, 0, (LONG)m_d3DImageInfo[1].Width, (LONG)m_d3DImageInfo[1].Height };
		D3DXVECTOR3	vcPos(bush2_pos[i], 330, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[1], &rt, NULL, &vcPos, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� Ǯ ��ġ
	float bush_pos[] = { -5, 300, 400 };	
	for (int i = 0; i < sizeof(bush_pos) / sizeof(float); i++) {
		RECT rt = { 0, 0, (LONG)m_d3DImageInfo[0].Width, (LONG)m_d3DImageInfo[0].Height };
		D3DXVECTOR3	vcPos(bush_pos[i], 440, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[0], &rt, NULL, &vcPos, D3DXCOLOR(1, 1, 1, 1));
	}

	// ���� ���� ��ġ
	float cloud_pos[] = { 80, 550 };		
	for (int i = 0; i < sizeof(cloud_pos) / sizeof(float); i++) {
		RECT rt = { 0, 0, 140, (LONG)m_d3DImageInfo[2].Height };
		D3DXVECTOR3	vcPos(cloud_pos[i], 20, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[2], &rt, NULL, &vcPos, D3DXCOLOR(1, 1, 1, 1));
	}
	
	// ū ���� ��ġ
	float cloud2_pos[] = { 350 };		
	for (int i = 0; i < sizeof(cloud2_pos) / sizeof(float); i++) {
		RECT rt = { 140, 0, 344, (LONG)m_d3DImageInfo[2].Height };
		D3DXVECTOR3	vcPos(cloud2_pos[i], 50, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[2], &rt, NULL, &vcPos, D3DXCOLOR(1, 1, 1, 1));
	}
	
	// �� ��ġ
	for (int i = 0; i <= 768; i += 128) {
		RECT rt = { 0, 0, (LONG)m_d3DImageInfo[3].Width, (LONG)m_d3DImageInfo[3].Height };
		D3DXVECTOR3	vcPos(i, 480, 0);
		m_pD3DSprite->Draw(m_pD3DTxtr[3], &rt, NULL, &vcPos, D3DXCOLOR(1, 1, 1, 1));
	}
	
	// ������ ��ġ
	//D3DXVECTOR3	vcPos(50, 400, 0);
	m_pD3DSprite->Draw(m_pD3DTxtr[4], &m_rt, NULL, &vcPos2, D3DXCOLOR(1, 1, 1, 1));
	return 0;
}

int num = 0;
//============================================
INT CMyGame::FrameMove()	{
	m_dwEndTime = timeGetTime();

	if ((m_dwEndTime - m_dwBeginTime) > 100) {
		if (move == 0) {
			m_rt = {384, 246, 448, 328};
		}
		if (move == 1) {
			m_rt = right_rt[num];
			vcPos2.x += 10; 
		} else if (move == 2) {
			m_rt = left_rt[num];
			vcPos2.x -= 10;
		} 
		
		num++;
		if (num > 3) {
			num = 0;
		}
		m_dwBeginTime = m_dwEndTime;
	}
	
	/*
	if ((m_dwEndTime - m_dwBeginTime) > 100) {
		m_rt = { x, 0, x2, 82 };
		
		m_dwBeginTime = m_dwEndTime;
		x += 64;
		x2 += 64;
		
		if (x2 > 256) {
			x = 0;
			x2 = 64;
		}
	}
	*/
	return 0; 
}

//============================================
void CMyGame::Destroy()
{
	//SAFE_RELEASE(m_pD3DTxtr);
	for (int i = 0; i < 5; i++) {
		SAFE_RELEASE(m_pD3DTxtr[i]);

	}
}//	void	CMyGame::Destroy()
//============================================
//*
LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg)
	{
		case WM_PAINT:		
		{			
			break;
		}
	}

	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}
//*/
//============================================