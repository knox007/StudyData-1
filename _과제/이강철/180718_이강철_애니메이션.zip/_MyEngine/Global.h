//========================================================
#pragma warning( disable : 4996)
//========================================================
#pragma once
//========================================================
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "winmm.lib")	//	timeGetTime
//========================================================
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <mmsystem.h>				//	timeGetTime
//========================================================
#include <tchar.h>
//========================================================
#include "Util.h"
#include "CDxCore.h"
#include "CMyGame.h"
//========================================================