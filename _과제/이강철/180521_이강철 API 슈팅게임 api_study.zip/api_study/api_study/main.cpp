#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
LPCTSTR lpszClass = TEXT("win_test");

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow) {
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = lpszClass;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);
	hWnd = CreateWindow(lpszClass, lpszClass, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	//ShowWindow(hWnd, nCmdShow);
	ShowWindow(hWnd, SW_MAXIMIZE);

	while (GetMessage(&Message, NULL, 0, 0)) {
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}
	return (int)Message.wParam;
}

#include "resource.h"
#include <time.h>

typedef struct {
	int bullet_x;
	int bullet_y;
	bool bullet_life;
} BULLET;

typedef struct {
	int enemy_x;
	int enemy_y;
	bool enemy_life;
} ENEMY;

BULLET bullet[100];
ENEMY enemy[5];

void draw_map(HDC hdc, int window_x, int window_y, int map_y, HBITMAP hbit) {
	HDC MemDC;
	HBITMAP OldBitmap;
	BITMAP bit;
	int bx, by;
	
	MemDC = CreateCompatibleDC(hdc);
	OldBitmap = (HBITMAP)SelectObject(MemDC, hbit);

	GetObject(hbit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	StretchBlt(hdc, 0, -window_y + map_y, window_x, window_y, MemDC, 0, 0, bx, by, SRCCOPY);
	StretchBlt(hdc, 0, map_y, window_x, window_y, MemDC, 0, 0, bx, by, SRCCOPY);
	SelectObject(MemDC, OldBitmap);
}

void draw_all(HDC hdc, int x, int y, int xx, int yy, int R, int G, int B, HBITMAP hbit) {
	HDC MemDC;
	HBITMAP OldBitmap;
	BITMAP bit;
	int bx, by;

	MemDC = CreateCompatibleDC(hdc);
	OldBitmap = (HBITMAP)SelectObject(MemDC, hbit);

	GetObject(hbit, sizeof(BITMAP), &bit);
	bx = bit.bmWidth;
	by = bit.bmHeight;

	TransparentBlt(hdc, x, y, bx / xx, by / yy, MemDC, 0, 0, bx, by, RGB(R, G, B));
	SelectObject(MemDC, OldBitmap);
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam) {
	srand(time(0));

	HDC hdc;
	RECT rc;							// ȭ���� ũ�⸦ �ҷ����� ���� rect
	static int map_y = 0;				// ���� �����̱� ���� y����
	int window_x, window_y;				// ������ ���̿� ������ ũ��
	static int bullet_cnt = 0;

	GetWindowRect(hWnd, &rc);
	window_x = rc.right - rc.left;
	window_y = rc.bottom - rc.top;

	static int my_x = 900, my_y = 900;   // ���� ��ġ ��ƾ� �ϴµ� �ϵ� �ڵ� �� �Ф�

	static HBITMAP map;
	static HBITMAP my_air; // ũ�Ⱑ 112?
	static HBITMAP my_bullet;
	static HBITMAP you_air;
	static HBITMAP boom;

	switch (iMessage) {
	case WM_CREATE:
		map = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		my_air = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP2));
		my_bullet = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP3));
		you_air = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP4));
		boom = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP5));

		SetTimer(hWnd, 1, 50, NULL);
		
		return 0;
	case WM_TIMER:
		map_y += 10;
		if (map_y >= window_y) {
			map_y = 0;
		}

		for (int i = 0; i < 5; i++) {
			if (enemy[i].enemy_life == false) {
				enemy[i].enemy_x = rand() % 1700 + 50;
				enemy[i].enemy_y = rand() % 450;
				enemy[i].enemy_life = true;
			}
		}

		for (int i = 0; i < 100; i++) {
			if (bullet[i].bullet_life == true) {
				bullet[i].bullet_y -= 50;
			}
			if (bullet[i].bullet_y <= -50) {
				bullet[i].bullet_life = false;
			}
		}

		for (int i = 0; i < 100; i++) {
			for (int j = 0; j < 5; j++) {
				if (bullet[i].bullet_life == true && bullet[i].bullet_y <= enemy[j].enemy_y && bullet[i].bullet_x >= enemy[j].enemy_x && bullet[i].bullet_x <= enemy[j].enemy_x+70) {
					bullet[i].bullet_life = false;
					enemy[j].enemy_life = false;
				}
			}
		}

		InvalidateRect(hWnd, NULL, FALSE);

		return 0;
	case WM_KEYDOWN:
		switch (wParam) {			
		case VK_LEFT:
			if (my_x > 8) {
				my_x -= 8;
			}
			break;
		case VK_RIGHT:
			if (my_x < window_x-112) {
				my_x += 8;
			}
			break;
		case VK_UP:
			if (my_y > 8) {
				my_y -= 8;
			}
			break;
		case VK_DOWN:
			if (my_y < window_y-112) {
				my_y += 8;
			}
			break;
		case VK_SPACE:
			bullet[bullet_cnt].bullet_x = my_x+35;
			bullet[bullet_cnt].bullet_y = my_y-45;
			bullet[bullet_cnt].bullet_life = true;
			bullet_cnt++;
			if (bullet_cnt >= 100) {
				bullet_cnt = 0;
			}
			break;
		}
	
		InvalidateRect(hWnd, NULL, FALSE);

		return 0;
	case WM_PAINT:
		PAINTSTRUCT ps;
		HDC MemDC;
		static HBITMAP MyBitmap;
		HBITMAP OldBitmap;

		hdc = BeginPaint(hWnd, &ps);

		if (MyBitmap) DeleteObject(MyBitmap);

		MemDC = CreateCompatibleDC(hdc);
		MyBitmap = CreateCompatibleBitmap(hdc, window_x, window_y * 2);

		OldBitmap = (HBITMAP)SelectObject(MemDC, MyBitmap);
		PatBlt(MemDC, 0, 0, window_x, window_y * 2, WHITENESS);

		draw_map(MemDC, window_x, window_y, map_y, map);
		draw_all(MemDC, my_x, my_y, 3, 3, 255, 255, 255, my_air);
		for (int i = 0; i < 100; i++) {
			if (bullet[i].bullet_life == true) {
				draw_all(MemDC, bullet[i].bullet_x, bullet[i].bullet_y, 5, 11, 255, 0, 0, my_bullet);
			}
		}
		for (int i = 0; i < 5; i++) {
			if (enemy[i].enemy_life == true) {
				draw_all(MemDC, enemy[i].enemy_x, enemy[i].enemy_y, 3, 3, 255, 255, 255, you_air);
			} else {
				draw_all(MemDC, enemy[i].enemy_x, enemy[i].enemy_y, 1, 1, 0, 0, 0, boom);
			}
		}

		BitBlt(hdc, 0, 0, window_x, window_y, MemDC, 0, 0, SRCCOPY);

		SelectObject(MemDC, OldBitmap);
		ReleaseDC(hWnd, hdc);
		DeleteDC(MemDC);

		EndPaint(hWnd, &ps);
		
		return 0;
	case WM_DESTROY:
		DeleteObject(map);
		DeleteObject(my_air);
		DeleteObject(my_bullet);
		DeleteObject(you_air);
		DeleteObject(boom);

		PostQuitMessage(0);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}