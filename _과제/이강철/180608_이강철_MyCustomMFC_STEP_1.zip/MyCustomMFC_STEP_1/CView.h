//====================================================
#pragma once
#include "CObject.h"
//====================================================
class CView : public CObject
{
public:
	static struct MsgMap g_MsgMap[];
	void OnCreate();
	void OnDraw();
	void OnDestroy();
	void OnLButtonDown();

};
//====================================================
extern CView g_View;
//====================================================

typedef void (CView::*CViewFuncPointer)();
struct MsgMap {
	UINT _Uint;
	CViewFuncPointer fp;
};

//extern MsgMap g_MsgMap[];