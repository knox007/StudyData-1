//========================================================
#pragma warning( disable : 4996)
//========================================================
#pragma once
//========================================================
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dx9.lib")
//========================================================
#include <windows.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <time.h>
//========================================================
#include <tchar.h>
#include <stdio.h>
//========================================================
#include "Util.h"
#include "CInputManager.h"
#include "CDxCore.h"
#include "CDxTexture.h"
#include "CDxFont.h"
//========================================================
#include "CMyGame.h"
//========================================================