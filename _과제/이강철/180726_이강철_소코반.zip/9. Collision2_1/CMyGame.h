//============================================
#pragma once
//============================================
#ifndef _MYGAME_H_
#define _MYGAME_H_
//============================================
#include "Global.h"
//============================================
class CMyGame : public CDxCore
{
public:
	CMyGame();
	virtual ~CMyGame();

	virtual INT		Init();
	virtual INT		Render();
	virtual INT		FrameMove();
	virtual void	Destroy();

	virtual LRESULT MsgProc(HWND, UINT, WPARAM, LPARAM);
	
	CDxTexture*		m_pDxTexture1;		// �÷��̾�
	CDxTexture*		m_pDxTexture2[10];	// �̴°�
	CDxTexture*		m_pDxTexture3[10];	// ��ǥ	
	CDxTexture*		m_pDxTexture4[100];	// ��	

	D3DXVECTOR3		m_vec3Pos1; 
	D3DXVECTOR3		m_vec3Pos2[10]; 
	D3DXVECTOR3		m_vec3Pos3[10];
	D3DXVECTOR3		m_vec3Pos4[100];

	INT MAP[20][20] = { 0 };
	INT STAGE1[11][19] = { { 0,0,0,0,4,4,4,4,4,0,0,0,0,0,0,0,0,0,0 },
						   { 0,0,0,0,4,0,0,0,4,0,0,0,0,0,0,0,0,0,0 },
						   { 0,0,0,0,4,2,0,0,4,0,0,0,0,0,0,0,0,0,0 },
						   { 0,0,4,4,4,0,0,2,4,4,0,0,0,0,0,0,0,0,0 },
						   { 0,0,4,0,0,2,0,2,0,4,0,0,0,0,0,0,0,0,0 },
						   { 4,4,4,0,4,0,4,4,0,4,0,0,0,4,4,4,4,4,4 },
						   { 4,0,0,0,4,0,4,4,0,4,4,4,4,4,0,0,3,3,4 },
						   { 4,0,2,0,0,2,0,0,0,0,0,0,0,0,0,0,3,3,4 },
						   { 4,4,4,4,4,0,4,4,4,0,4,1,4,4,0,0,3,3,4 },
						   { 0,0,0,0,4,0,0,0,0,0,4,4,4,4,4,4,4,4,4 },
						   { 0,0,0,0,4,4,4,4,4,4,4,0,0,0,0,0,0,0,0 } };

	INT STAGE2[9][8] =   { { 0,0,4,4,4,4,4,0 },
						   { 4,4,4,0,0,0,4,0 },
						   { 4,3,1,2,0,0,4,0 },
						   { 4,4,4,0,2,3,4,0 },
						   { 4,3,4,4,2,0,4,0 },
						   { 4,0,4,0,3,0,4,4 },
						   { 4,2,0,2,2,2,3,4 },
						   { 4,0,0,0,3,0,0,4 },
						   { 4,4,4,4,4,4,4,4 } };
	
	INT				NOW_STAGE = 1;
	INT				STAGE_X;
	INT				STAGE_Y;

	INT				OBJ_CNT;
	INT				GOAL_CNT;
	INT				WALL_CNT;
	
	INT				MOVE_INDEX;

	BOOL            WALL_CHECK;
	BOOL            OBJ_CHECK;
	INT				OBJ_INDEX;

	BOOL			SUCCESS_FLAG[10];
	INT				SUCCESS_CNT[10];

	CDxFont			m_dxFont;

};// class CMyGame :	public CDxCore

extern CMyGame*	g_pApp;
//============================================
#endif // _MYGAME_H_
//============================================