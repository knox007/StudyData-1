//============================================
#include "Global.h"
//============================================
#define MOVEOFFSET	30.0F
//============================================
CMyGame::CMyGame()
{
	
}//	CMyGame::CMyGame()
//============================================
CMyGame::~CMyGame()	{}
//============================================
INT		CMyGame::Init()
{
	srand((unsigned)time(NULL));

	if (NOW_STAGE == 1) {
		STAGE_X = 11;
		STAGE_Y = 19;

		for (int i = 0; i < STAGE_X; i++) {
			for (int j = 0; j < STAGE_Y; j++) {
				MAP[i][j] = STAGE1[i][j];
			}
		}
	} else if (NOW_STAGE == 2) {
		STAGE_X = 9;
		STAGE_Y = 8;

		for (int i = 0; i < STAGE_X; i++) {
			for (int j = 0; j < STAGE_Y; j++) {
				MAP[i][j] = STAGE2[i][j];
			}
		}
	}
	
	OBJ_CNT = 0;
	GOAL_CNT = 0;
	WALL_CNT = 0;

	MOVE_INDEX = 0;

	WALL_CHECK = TRUE;
	OBJ_CHECK = TRUE;
	OBJ_INDEX = 0;

	SUCCESS_FLAG[10] = { FALSE };
	SUCCESS_CNT[10] = { 0 };

	for (int i = 0; i < STAGE_X; i++) {
		for (int j = 0; j < STAGE_Y; j++) {
			if (MAP[i][j] == 1) { // �÷��̾�
				m_pDxTexture1 = new CDxTexture;
				if (FAILED(m_pDxTexture1->Create(m_pD3DDevice, "texture/A3.png")))				
					return -1;
				
				m_vec3Pos1 = D3DXVECTOR3(j * 30, i * 30, 0);
			} else if (MAP[i][j] == 2) { // ��ü
				m_pDxTexture2[OBJ_CNT] = new CDxTexture;
				if (FAILED(m_pDxTexture2[OBJ_CNT]->Create(m_pD3DDevice, "texture/B3.png"))) 
					return -1;

				m_vec3Pos2[OBJ_CNT] = D3DXVECTOR3(j * 30, i * 30, 0);
				OBJ_CNT++;
			} else if (MAP[i][j] == 3) { // ��ǥ
				m_pDxTexture3[GOAL_CNT] = new CDxTexture;
				if (FAILED(m_pDxTexture3[GOAL_CNT]->Create(m_pD3DDevice, "texture/C3.png")))
					return -1;

				m_vec3Pos3[GOAL_CNT] = D3DXVECTOR3(j * 30, i * 30, 0);
				GOAL_CNT++;
			} else if (MAP[i][j] == 4) { // ��
				m_pDxTexture4[WALL_CNT] = new CDxTexture;
				if (FAILED(m_pDxTexture4[WALL_CNT]->Create(m_pD3DDevice, "texture/D3.png"))) 
					return -1;

				m_vec3Pos4[WALL_CNT] = D3DXVECTOR3(j * 30,  i * 30, 0);
				WALL_CNT++;
			}
		}
	}

	m_pInputManager = new CInputManager();
	m_pInputManager->Create(m_hWnd);
	
	return 0;

}//	INT		CMyGame::Init()
//============================================
INT		CMyGame::Render()
{
	RECT rc;
	for (int i = 0; i < GOAL_CNT; i++) {
		m_pDxTexture3[i]->GetImageRect(&rc);
		m_pD3DSprite->Draw(m_pDxTexture3[i]->GetTexture(), &rc, NULL, &m_vec3Pos3[i], D3DXCOLOR(1, 1, 1, 1));
	}

	for (int i = 0; i < WALL_CNT; i++) {
		m_pDxTexture4[i]->GetImageRect(&rc);
		m_pD3DSprite->Draw(m_pDxTexture4[i]->GetTexture(), &rc, NULL, &m_vec3Pos4[i], D3DXCOLOR(1, 1, 1, 1));
	}

	for (int i = 0; i < OBJ_CNT; i++) {
		m_pDxTexture2[i]->GetImageRect(&rc);
		m_pD3DSprite->Draw(m_pDxTexture2[i]->GetTexture(), &rc, NULL, &m_vec3Pos2[i], D3DXCOLOR(1, 1, 1, 1));
	}

	m_pDxTexture1->GetImageRect(&rc);
	m_pD3DSprite->Draw(m_pDxTexture1->GetTexture(), &rc, NULL, &m_vec3Pos1, D3DXCOLOR(1, 1, 1, 1));

	return 0;
}//	INT		CMyGame::Render()
//============================================

INT		CMyGame::FrameMove()
{
	if (m_pInputManager)
	{
		m_pInputManager->FrameMove();

		// �÷��̾� ������ �� ���� ��
		D3DXVECTOR3 tmpPos1 = m_vec3Pos1;

		// ��ü ������ �� ���� ��
		D3DXVECTOR3 tmpPos2[10];
		for (int i = 0; i < OBJ_CNT; i++) {
			tmpPos2[i] = m_vec3Pos2[i];
		}

		// �÷��̾� ���� ������ �̸� �̵�
		if (m_pInputManager->KeyDown(VK_RIGHT)) {
			tmpPos1.x += MOVEOFFSET;
			MOVE_INDEX = 1;
		}

		if (m_pInputManager->KeyDown(VK_LEFT)) {
			tmpPos1.x -= MOVEOFFSET;
			MOVE_INDEX = 2;
		}

		if (m_pInputManager->KeyDown(VK_UP)) {
			tmpPos1.y -= MOVEOFFSET;
			MOVE_INDEX = 3;
		}

		if (m_pInputManager->KeyDown(VK_DOWN)) {
			tmpPos1.y += MOVEOFFSET;
			MOVE_INDEX = 4;
		}

		if (m_pInputManager->KeyDown(VK_SPACE)) {

		}

		// ���� ���� ��ü���� �浹 ���� ����
		RECT rcTemp, rcCol1, rcCol2[10], rcCol3[10], rcCol4[100];
		SetRect(&rcCol1, INT(tmpPos1.x)
			, INT(tmpPos1.y)
			, INT(tmpPos1.x) + m_pDxTexture1->GetImageWidth()
			, INT(tmpPos1.y) + m_pDxTexture1->GetImageHeight()
		);

		for (int i = 0; i < OBJ_CNT; i++) {
			SetRect(&rcCol2[i], INT(m_vec3Pos2[i].x)
				, INT(m_vec3Pos2[i].y)
				, INT(m_vec3Pos2[i].x) + m_pDxTexture2[i]->GetImageWidth()
				, INT(m_vec3Pos2[i].y) + m_pDxTexture2[i]->GetImageHeight()
			);
		}

		for (int i = 0; i < GOAL_CNT; i++) {
			SetRect(&rcCol3[i], INT(m_vec3Pos3[i].x)
				, INT(m_vec3Pos3[i].y)
				, INT(m_vec3Pos3[i].x) + m_pDxTexture3[i]->GetImageWidth()
				, INT(m_vec3Pos3[i].y) + m_pDxTexture3[i]->GetImageHeight()
			);
		}

		for (int i = 0; i < WALL_CNT; i++) {
			SetRect(&rcCol4[i], INT(m_vec3Pos4[i].x)
				, INT(m_vec3Pos4[i].y)
				, INT(m_vec3Pos4[i].x) + m_pDxTexture4[i]->GetImageWidth()
				, INT(m_vec3Pos4[i].y) + m_pDxTexture4[i]->GetImageHeight()
			);
		}

		// �÷��̾� ���̰��� ���� �浹 üũ
		WALL_CHECK = TRUE;
		OBJ_CHECK = TRUE;

		// �� üũ
		for (int i = 0; i < WALL_CNT; i++) {
			if (IntersectRect(&rcTemp, &rcCol1, &rcCol4[i])) {
				WALL_CHECK = FALSE;
			}
		}
		
		// ��ü üũ
		if (WALL_CHECK) {
			for (int i = 0; i < OBJ_CNT; i++) {
				if (IntersectRect(&rcTemp, &rcCol1, &rcCol2[i])) {
					OBJ_CHECK = FALSE;
					OBJ_INDEX = i;
				}
			}
		}

		// �浹 ����
		if (WALL_CHECK && OBJ_CHECK) { // ���� �ƴϰ� ��ü�� �ƴϸ� ��������
			m_vec3Pos1 = tmpPos1;
		} else if (WALL_CHECK && !OBJ_CHECK) { // ���� �ƴѵ� ��ü�� �ִٸ� ��ü�� �̴� �������� ���̰��� �����̰�
			WALL_CHECK = TRUE;
			OBJ_CHECK = TRUE;
			
			if (MOVE_INDEX == 1) {
				tmpPos2[OBJ_INDEX].x += MOVEOFFSET;
			} else if (MOVE_INDEX == 2) {
				tmpPos2[OBJ_INDEX].x -= MOVEOFFSET;
			} else if (MOVE_INDEX == 3) {
				tmpPos2[OBJ_INDEX].y -= MOVEOFFSET;
			} else if (MOVE_INDEX == 4) {
				tmpPos2[OBJ_INDEX].y += MOVEOFFSET;
			}

			SetRect(&rcCol2[OBJ_INDEX], INT(tmpPos2[OBJ_INDEX].x)
				, INT(tmpPos2[OBJ_INDEX].y)
				, INT(tmpPos2[OBJ_INDEX].x) + m_pDxTexture2[OBJ_INDEX]->GetImageWidth()
				, INT(tmpPos2[OBJ_INDEX].y) + m_pDxTexture2[OBJ_INDEX]->GetImageHeight()
			);

			for (int i = 0; i < WALL_CNT; i++) { // �ش� ��ü�� ���� üũ�� ����.
				if (IntersectRect(&rcTemp, &rcCol2[OBJ_INDEX], &rcCol4[i])) {
					WALL_CHECK = FALSE;
				}
			}

			if (WALL_CHECK) { // ���� �ƴϸ� �ش� ��ü�� �ٸ� ��ü�� üũ�� ����.
				for (int i = 0; i < OBJ_CNT; i++) {
					if (i != OBJ_INDEX) {
						if (IntersectRect(&rcTemp, &rcCol2[OBJ_INDEX], &rcCol2[i])) {
							OBJ_CHECK = FALSE;
						}
					}
				}
			}

			if (WALL_CHECK && OBJ_CHECK) {
				m_vec3Pos1 = tmpPos1;
				m_vec3Pos2[OBJ_INDEX] = tmpPos2[OBJ_INDEX];
			}
		}
		
		// ���� ���� ����
		for (int i = 0; i < OBJ_CNT; i++) {
			SUCCESS_FLAG[i] = FALSE;
			for (int j = 0; j < GOAL_CNT; j++) {
				if (IntersectRect(&rcTemp, &rcCol2[i], &rcCol3[j])) {
					SUCCESS_FLAG[i] = TRUE;
				}
			}
		}

		for (int i = 0; i < GOAL_CNT; i++) {
			if (SUCCESS_FLAG[i]) {
				SUCCESS_CNT[i] = 1;
			} else {
				SUCCESS_CNT[i] = 0;
			}
		}
		
		TCHAR CCNT[128];
		INT SUCCESS = 0;
		for (int i = 0; i < GOAL_CNT; i++) {
			SUCCESS += SUCCESS_CNT[i];
		}
		wsprintf(CCNT, "%d�� ����~!!!", SUCCESS);
		SetWindowText(m_hWnd, CCNT);

		if (NOW_STAGE == 1 && SUCCESS == GOAL_CNT) {
				NOW_STAGE++;
				Init();
		} else if (NOW_STAGE == 2 && SUCCESS == GOAL_CNT) {
			
		}

	}//	if (m_pInputManager)

	return 0;

}//	INT		CMyGame::FrameMove()
//============================================
void	CMyGame::Destroy()
{
	SAFE_DELETE(m_pDxTexture1);
	for (int i = 0; i < 10; i++) {
		SAFE_DELETE(m_pDxTexture2[i]);
		SAFE_DELETE(m_pDxTexture3[i]);
	}

	for (int i = 0; i < 100; i++) {
		SAFE_DELETE(m_pDxTexture4[i]);	
	}

	SAFE_DELETE(m_pInputManager);

	m_dxFont.Destroy();
}
//============================================
LRESULT CMyGame::MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	if (m_pInputManager)
		m_pInputManager->MsgProc(hWnd, msg, wParam, lParam);

	switch (msg)
	{
		case WM_PAINT:
		{
			break;
		}
	}

	return CDxCore::MsgProc(hWnd, msg, wParam, lParam);
}