FBXLoader
=========

**FBX Loader for Direct3D11**

FBXを読み込んでDirect3D11で描画するサンプルです。  
描画モードは、通常の描画モードとインスタンシング描画の2つがあります(F2キーで切り替え)。

ライセンス  
商用・非商用好きに使用してかまいません。

- Visual Studio 2012
- FBX SDK 2014.2(下記からダウンロードできます。)
	- http://usa.autodesk.com/adsk/servlet/pc/item?siteID=123112&id=10775847
- DirectXTKを使用しています。
	- http://directxtk.codeplex.com/
- FBX SDK 2015とVisual Studio 2013対応版はこちら
	- https://github.com/shaderjp/FBXLoader2015forDX11
